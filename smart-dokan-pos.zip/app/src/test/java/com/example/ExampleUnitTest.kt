package com.example

import com.example.data.local.ProductEntity
import com.example.data.local.SaleEntity
import com.example.data.prefs.DriveDataScope
import com.example.data.prefs.DriveLinkParser
import com.example.data.prefs.ShopProfile
import com.example.data.prefs.ThemeConfig
import com.example.data.sync.BackupSnapshot
import com.example.security.VaultCrypto
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun product_profit_and_margin_calculated_accurately() {
    val product =
      ProductEntity(
        name = "Napa Extra",
        buyingPrice = 20.0,
        sellingPrice = 25.0,
        stock = 10,
        imagePath = "/data/user/0/com.example/files/product_images/prod_1.jpg",
      )
    assertEquals(5.0, product.unitProfit, 0.001)
    assertEquals(20.0, product.marginPercent, 0.001)
    assertTrue(product.imagePath.endsWith(".jpg"))
  }

  @Test
  fun drive_link_parser_extracts_folder_id_and_validates_folder_inputs() {
    val folderUrl = "https://drive.google.com/drive/folders/1AbCdEfGhIjKlMnOpQrSt?usp=sharing"
    assertEquals("1AbCdEfGhIjKlMnOpQrSt", DriveLinkParser.extractFolderId(folderUrl))
    assertTrue(DriveLinkParser.isValidDriveFolderInput(folderUrl))
    assertTrue(DriveLinkParser.isValidDriveFolderInput(""))
    assertFalse(DriveLinkParser.isValidDriveFolderInput("not-a-valid-folder"))
    assertTrue(
      DriveLinkParser.isValidAppsScriptEndpoint("https://script.google.com/macros/s/AKfycbxyz/exec")
    )
    assertFalse(DriveLinkParser.isValidAppsScriptEndpoint("https://evil.example.com/hook"))
    assertEquals(5, DriveDataScope.entries.size)
  }

  @Test
  fun shop_profile_and_backup_snapshot_v2_defaults_are_valid() {
    val profile = ShopProfile(shopName = "মা ফার্মেসি", currencySymbol = "৳", lowStockThreshold = 8)
    val snapshot =
      BackupSnapshot(
        themeConfig = ThemeConfig(),
        shopProfile = profile,
        products = listOf(ProductEntity(id = 1, name = "Seclo 20", buyingPrice = 5.0, sellingPrice = 6.0, stock = 50)),
        sales = listOf(
          SaleEntity(
            id = 1,
            productId = 1,
            productName = "Seclo 20",
            quantity = 2,
            buyingPriceAtSale = 5.0,
            sellingPriceAtSale = 6.0,
            totalRevenue = 12.0,
            totalCost = 10.0,
            netProfit = 2.0,
            dateKey = "2026-11-22",
          )
        ),
      )
    assertEquals(2, snapshot.schemaVersion)
    assertEquals("মা ফার্মেসি", snapshot.shopProfile.shopName)
    assertEquals(8, snapshot.shopProfile.lowStockThreshold)
    assertEquals(1, snapshot.products.size)
    assertEquals(1, snapshot.sales.size)
  }

  @Test
  fun vault_crypto_encrypts_and_decrypts_aes_256_gcm() {
    val secretJson = """{"shop":"Smart Dokan","profit":1250.5}"""
    val passphrase = "my-shop-vault-pin"
    val envelope = VaultCrypto.encrypt(secretJson, passphrase)
    val decrypted = VaultCrypto.decrypt(envelope, passphrase)
    assertEquals(secretJson, decrypted)

    assertThrows(IllegalArgumentException::class.java) {
      VaultCrypto.decrypt(envelope, "wrong-passphrase")
    }
  }
}
