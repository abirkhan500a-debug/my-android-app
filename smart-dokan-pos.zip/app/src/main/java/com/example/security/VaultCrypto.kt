package com.example.security

import com.example.data.sync.EncryptedVaultEnvelope
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi

/**
 * Client-side zero-knowledge AES-256-GCM encryption using PBKDF2WithHmacSHA256.
 * No encryption keys or secrets are ever stored in source code.
 */
@OptIn(ExperimentalEncodingApi::class)
object VaultCrypto {
  private const val PBKDF2_ITERATIONS = 120_000
  private const val KEY_LENGTH_BITS = 256
  private const val SALT_BYTES = 16
  private const val IV_BYTES = 12
  private const val GCM_TAG_BITS = 128

  private fun deriveKey(passphrase: String, salt: ByteArray): SecretKeySpec {
    val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
    val spec = PBEKeySpec(passphrase.toCharArray(), salt, PBKDF2_ITERATIONS, KEY_LENGTH_BITS)
    val secret = factory.generateSecret(spec)
    return SecretKeySpec(secret.encoded, "AES")
  }

  fun encrypt(plaintextJson: String, passphrase: String): EncryptedVaultEnvelope {
    require(passphrase.length >= 4) { "ভল্ট পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে।" }
    val rng = SecureRandom()
    val salt = ByteArray(SALT_BYTES).also { rng.nextBytes(it) }
    val iv = ByteArray(IV_BYTES).also { rng.nextBytes(it) }

    val key = deriveKey(passphrase, salt)
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
    val ciphertext = cipher.doFinal(plaintextJson.toByteArray(Charsets.UTF_8))

    return EncryptedVaultEnvelope(
      v = 1,
      alg = "AES-256-GCM",
      salt = Base64.encode(salt),
      iv = Base64.encode(iv),
      ciphertext = Base64.encode(ciphertext),
      createdAt = System.currentTimeMillis(),
    )
  }

  fun decrypt(envelope: EncryptedVaultEnvelope, passphrase: String): String {
    require(passphrase.isNotEmpty()) { "ডিক্রিপ্ট করতে ভল্ট পাসওয়ার্ড দিন।" }
    val salt = Base64.decode(envelope.salt.trim())
    val iv = Base64.decode(envelope.iv.trim())
    val ciphertext = Base64.decode(envelope.ciphertext.trim())

    val key = deriveKey(passphrase, salt)
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
    return try {
      val plainBytes = cipher.doFinal(ciphertext)
      String(plainBytes, Charsets.UTF_8)
    } catch (_: Exception) {
      throw IllegalArgumentException("ভল্ট পাসওয়ার্ড ভুল হয়েছে অথবা ব্যাকআপ ফাইলটি ক্ষতিগ্রস্ত।")
    }
  }
}
