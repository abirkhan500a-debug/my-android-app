package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.prefs.ShopProfile
import com.example.ui.theme.LocalGlassPalette

@Composable
fun ShopProfileDialog(
  currentProfile: ShopProfile,
  onDismiss: () -> Unit,
  onSave: (ShopProfile) -> Unit,
) {
  val glass = LocalGlassPalette.current
  var shopName by remember(currentProfile) { mutableStateOf(currentProfile.shopName) }
  var shopSubtitle by remember(currentProfile) { mutableStateOf(currentProfile.shopSubtitle) }
  var phone by remember(currentProfile) { mutableStateOf(currentProfile.phone) }
  var address by remember(currentProfile) { mutableStateOf(currentProfile.address) }
  var thresholdText by remember(currentProfile) {
    mutableStateOf(currentProfile.lowStockThreshold.toString())
  }
  var currency by remember(currentProfile) { mutableStateOf(currentProfile.currencySymbol) }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false),
  ) {
    GlassCard(
      modifier = Modifier.fillMaxWidth(0.92f).padding(vertical = 16.dp),
      shape = RoundedCornerShape(26.dp),
      innerPadding = 18.dp,
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Storefront, contentDescription = "দোকান প্রোফাইল", tint = glass.accent)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "দোকানের তথ্য ও সেটিংস এডিট",
            style = MaterialTheme.typography.titleLarge,
            color = glass.textPrimary,
          )
        }
        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "বন্ধ করুন", tint = glass.textPrimary)
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Column(
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        OutlinedTextField(
          value = shopName,
          onValueChange = { shopName = it },
          label = { Text("দোকানের নাম *") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("shop_name_input"),
        )
        OutlinedTextField(
          value = shopSubtitle,
          onValueChange = { shopSubtitle = it },
          label = { Text("দোকানের ধরন / স্লোগান") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("shop_subtitle_input"),
        )
        OutlinedTextField(
          value = phone,
          onValueChange = { phone = it },
          label = { Text("মোবাইল নম্বর") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("shop_phone_input"),
        )
        OutlinedTextField(
          value = address,
          onValueChange = { address = it },
          label = { Text("দোকানের ঠিকানা") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("shop_address_input"),
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          OutlinedTextField(
            value = thresholdText,
            onValueChange = { thresholdText = it.filter { c -> c.isDigit() } },
            label = { Text("শর্ট লিস্ট সীমা") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.weight(1f).testTag("shop_threshold_input"),
          )
          OutlinedTextField(
            value = currency,
            onValueChange = { currency = it.take(3) },
            label = { Text("কারেন্সি চিহ্ন") },
            singleLine = true,
            modifier = Modifier.weight(0.8f).testTag("shop_currency_input"),
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        OutlinedButton(onClick = onDismiss) { Text("বাতিল") }
        Spacer(modifier = Modifier.width(10.dp))
        Button(
          onClick = {
            onSave(
              ShopProfile(
                shopName = shopName.trim().ifEmpty { "Smart Dokan POS" },
                shopSubtitle = shopSubtitle.trim(),
                phone = phone.trim(),
                address = address.trim(),
                currencySymbol = currency.trim().ifEmpty { "৳" },
                lowStockThreshold = (thresholdText.toIntOrNull() ?: 5).coerceIn(1, 500),
              )
            )
            onDismiss()
          },
          colors = ButtonDefaults.buttonColors(containerColor = glass.accent, contentColor = Color.White),
          modifier = Modifier.testTag("save_shop_profile_button"),
        ) {
          Text("সেভ করুন", fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}
