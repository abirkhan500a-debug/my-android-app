package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.prefs.BlurIntensity
import com.example.data.prefs.MeshStyle
import com.example.data.prefs.ThemeConfig
import com.example.data.prefs.ThemePreset
import com.example.ui.theme.LocalGlassPalette

private val ACCENT_SWATCHES =
  listOf(
    0xFF059669L,
    0xFF2563EBL,
    0xFFD97706L,
    0xFFE11D48L,
    0xFF7C3AEDL,
    0xFF0D9488L,
    0xFF18181BL,
  )

private val BG_SWATCH_PAIRS =
  listOf(
    0xFFD1FAE5L to 0xFFCCFBF1L,
    0xFFDBEAFEL to 0xFFE0F2FEL,
    0xFFFEF3C7L to 0xFFFFEDD5L,
    0xFFFFE4E6L to 0xFFFCE7F3L,
    0xFF020617L to 0xFF064E3BL,
    0xFF0F172AL to 0xFF1E1B4BL,
  )

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ThemeStudioSheet(
  themeConfig: ThemeConfig,
  onSelectPreset: (ThemePreset) -> Unit,
  onUpdateCustom: (
    accentHex: Long?,
    bgStartHex: Long?,
    bgEndHex: Long?,
    meshStyle: MeshStyle?,
    blurIntensity: BlurIntensity?,
  ) -> Unit,
  onDismiss: () -> Unit,
) {
  val glass = LocalGlassPalette.current
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = glass.glassBarBg,
  ) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 20.dp)
          .navigationBarsPadding()
          .padding(bottom = 24.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          Icons.Default.Palette,
          contentDescription = "থিম স্টুডিও",
          tint = glass.accent,
          modifier = Modifier.size(26.dp),
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = "থিম ও ডিজাইন কাস্টমাইজার",
            style = MaterialTheme.typography.titleLarge,
            color = glass.textPrimary,
          )
          Text(
            text = "রিয়েল-টাইমে দোকানের গ্লাস ইফেক্ট ও রঙ সাজান",
            style = MaterialTheme.typography.bodyMedium,
            color = glass.textSecondary,
          )
        }
      }

      // 6 Preset Palettes
      Text(
        text = "প্রিসেট কালার প্যালেট (৬টি ডিজাইন)",
        style = MaterialTheme.typography.titleMedium,
        color = glass.textPrimary,
      )

      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        ThemePreset.entries.chunked(2).forEach { pair ->
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            pair.forEach { preset ->
              val selected = themeConfig.presetId == preset.id
              Surface(
                modifier =
                  Modifier.weight(1f)
                    .testTag("theme_preset_${preset.id}")
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { onSelectPreset(preset) },
                shape = RoundedCornerShape(16.dp),
                border =
                  BorderStroke(
                    width = if (selected) 2.dp else 1.dp,
                    color = if (selected) Color(preset.accentHex) else glass.glassBorder,
                  ),
                color = Color.Transparent,
              ) {
                Row(
                  modifier =
                    Modifier.background(
                        Brush.linearGradient(
                          listOf(Color(preset.bgStartHex), Color(preset.bgEndHex))
                        )
                      )
                      .padding(horizontal = 12.dp, vertical = 12.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Box(
                    modifier =
                      Modifier.size(26.dp)
                        .clip(CircleShape)
                        .background(Color(preset.accentHex))
                        .border(2.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center,
                  ) {
                    if (selected) {
                      Icon(
                        Icons.Default.Check,
                        contentDescription = "নির্বাচিত",
                        tint = Color.White,
                        modifier = Modifier.size(15.dp),
                      )
                    }
                  }
                  Spacer(modifier = Modifier.width(8.dp))
                  Column {
                    Text(
                      text = preset.labelBn,
                      style = MaterialTheme.typography.labelLarge,
                      color = if (preset.isDark) Color.White else Color(0xFF0F172A),
                      maxLines = 1,
                    )
                    Text(
                      text = if (preset.isDark) "ডার্ক গ্লাস" else "লাইট গ্লাস",
                      style = MaterialTheme.typography.labelSmall,
                      color = if (preset.isDark) Color(0xFFCBD5E1) else Color(0xFF475569),
                    )
                  }
                }
              }
            }
          }
        }
      }

      // Custom Accent Color Swatches
      Text(
        text = "কাস্টম প্রাইমারি অ্যাকসেন্ট কালার",
        style = MaterialTheme.typography.titleMedium,
        color = glass.textPrimary,
      )
      FlowRow(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        ACCENT_SWATCHES.forEachIndexed { idx, hex ->
          val selected = themeConfig.customAccentHex == hex
          Box(
            modifier =
              Modifier.size(44.dp)
                .testTag("accent_swatch_$idx")
                .clip(CircleShape)
                .background(Color(hex))
                .border(
                  width = if (selected) 3.dp else 1.5.dp,
                  color = if (selected) Color.White else glass.glassBorder,
                  shape = CircleShape,
                )
                .clickable { onUpdateCustom(hex, null, null, null, null) },
            contentAlignment = Alignment.Center,
          ) {
            if (selected) {
              Icon(Icons.Default.Check, contentDescription = "নির্বাচিত রঙ", tint = Color.White)
            }
          }
        }
      }

      // Custom Background Mesh Colors
      Text(
        text = "ব্যাকগ্রাউন্ড গ্রেডিয়েন্ট টোন",
        style = MaterialTheme.typography.titleMedium,
        color = glass.textPrimary,
      )
      FlowRow(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        BG_SWATCH_PAIRS.forEachIndexed { idx, (startHex, endHex) ->
          val selected =
            themeConfig.customBgStartHex == startHex && themeConfig.customBgEndHex == endHex
          Box(
            modifier =
              Modifier.size(width = 56.dp, height = 38.dp)
                .testTag("bg_swatch_$idx")
                .clip(RoundedCornerShape(12.dp))
                .background(Brush.linearGradient(listOf(Color(startHex), Color(endHex))))
                .border(
                  width = if (selected) 2.5.dp else 1.dp,
                  color = if (selected) glass.accent else glass.glassBorder,
                  shape = RoundedCornerShape(12.dp),
                )
                .clickable { onUpdateCustom(null, startHex, endHex, null, null) },
          )
        }
      }

      // Mesh Gradient Style
      Text(
        text = "ব্যাকগ্রাউন্ড মেশ স্টাইল",
        style = MaterialTheme.typography.titleMedium,
        color = glass.textPrimary,
      )
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        MeshStyle.entries.forEach { style ->
          FilterChip(
            selected = themeConfig.meshStyle == style,
            onClick = { onUpdateCustom(null, null, null, style, null) },
            label = { Text(style.labelBn, maxLines = 1) },
            modifier = Modifier.weight(1f).testTag("mesh_style_${style.name}"),
          )
        }
      }

      // Glass Blur Intensity
      Text(
        text = "গ্লাস ফ্রস্ট ও স্বচ্ছতা (Glass Intensity)",
        style = MaterialTheme.typography.titleMedium,
        color = glass.textPrimary,
      )
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        BlurIntensity.entries.forEach { blur ->
          FilterChip(
            selected = themeConfig.blurIntensity == blur,
            onClick = { onUpdateCustom(null, null, null, null, blur) },
            label = { Text(blur.labelBn, maxLines = 1) },
            modifier = Modifier.weight(1f).testTag("blur_level_${blur.name}"),
          )
        }
      }

      Button(
        onClick = onDismiss,
        colors = ButtonDefaults.buttonColors(containerColor = glass.accent, contentColor = Color.White),
        modifier = Modifier.fillMaxWidth().height(50.dp).testTag("theme_done_button"),
      ) {
        Text("সম্পন্ন করুন", fontWeight = FontWeight.Bold)
      }
    }
  }
}
