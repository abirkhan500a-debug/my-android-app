package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddLink
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.WifiTethering
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.prefs.DriveDataScope
import com.example.data.prefs.DriveLinkStatus
import com.example.data.prefs.UserDriveLink
import com.example.ui.theme.DangerRose
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalGlassPalette
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.WarningAmber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val USER_APPS_SCRIPT_CODE = """function getOrCreateFolder(parent, name) {
  var it = parent.getFoldersByName(name);
  if (it.hasNext()) return it.next();
  var sub = parent.createFolder(name);
  sub.setSharing(DriveApp.Access.PRIVATE, DriveApp.Permission.NONE);
  return sub;
}

function upsertPrivateFile(folder, name, textContent) {
  var files = folder.getFilesByName(name);
  if (files.hasNext()) { files.next().setContent(textContent); }
  else {
    var f = folder.createFile(name, textContent, MimeType.PLAIN_TEXT);
    f.setSharing(DriveApp.Access.PRIVATE, DriveApp.Permission.NONE);
  }
}

function doPost(e) {
  var req = JSON.parse(e.postData.contents);
  var root = req.folderId ? DriveApp.getFolderById(req.folderId) : getOrCreateFolder(DriveApp.getRootFolder(), "SmartDokan_Backup");
  if (req.mode === "ping") {
    return ContentService.createTextOutput(JSON.stringify({ success: true })).setMimeType(ContentService.MimeType.JSON);
  }
  var quotaLeft = DriveApp.getStorageLimit() - DriveApp.getStorageUsed();
  if (req.mode === "sync") {
    if (quotaLeft < 50 * 1024 * 1024) {
      return ContentService.createTextOutput(JSON.stringify({ success: false, quotaFull: true, error: "ড্রাইভ স্টোরেজ প্রায় পূর্ণ!" })).setMimeType(ContentService.MimeType.JSON);
    }
    var useSubs = req.autoSubfolders !== false;
    var scope = req.dataScope || "ALL_AUTO_SUBFOLDERS";
    var dateKey = req.dateKey || new Date().toISOString().slice(0, 10);
    var vaultFolder = useSubs && scope === "ALL_AUTO_SUBFOLDERS" ? getOrCreateFolder(root, "04_Encrypted_Vault") : root;
    upsertPrivateFile(vaultFolder, req.filename, JSON.stringify(req.payload));
    if (req.structuredData) {
      if (req.structuredData.products && (scope === "ALL_AUTO_SUBFOLDERS" || scope === "PRODUCTS_ONLY")) {
        var pFolder = useSubs && scope === "ALL_AUTO_SUBFOLDERS" ? getOrCreateFolder(root, "01_Products_Stock") : root;
        upsertPrivateFile(pFolder, "products_inventory.json", JSON.stringify(req.structuredData.products, null, 2));
      }
      if (req.structuredData.sales && (scope === "ALL_AUTO_SUBFOLDERS" || scope === "SALES_ONLY")) {
        var sFolder = useSubs && scope === "ALL_AUTO_SUBFOLDERS" ? getOrCreateFolder(root, "02_Daily_Sales_Profit") : root;
        upsertPrivateFile(sFolder, "sales_" + dateKey + ".json", JSON.stringify(req.structuredData.sales, null, 2));
      }
      if (req.structuredData.shortList && (scope === "ALL_AUTO_SUBFOLDERS" || scope === "SHORTLIST_ONLY")) {
        var lFolder = useSubs && scope === "ALL_AUTO_SUBFOLDERS" ? getOrCreateFolder(root, "03_Short_List") : root;
        upsertPrivateFile(lFolder, "short_list.json", JSON.stringify(req.structuredData.shortList, null, 2));
      }
    }
    return ContentService.createTextOutput(JSON.stringify({ success: true, syncedAt: new Date().toISOString() })).setMimeType(ContentService.MimeType.JSON);
  }
  if (req.mode === "restore") {
    var vFolder = (req.autoSubfolders !== false && (req.dataScope || "") === "ALL_AUTO_SUBFOLDERS")
      ? getOrCreateFolder(root, "04_Encrypted_Vault") : root;
    var files = vFolder.getFilesByName(req.filename);
    if (!files.hasNext()) files = root.getFilesByName(req.filename);
    if (!files.hasNext()) return ContentService.createTextOutput(JSON.stringify({ success: false, error: "ব্যাকআপ পাওয়া যায়নি।" })).setMimeType(ContentService.MimeType.JSON);
    var data = JSON.parse(files.next().getBlob().getDataAsString());
    return ContentService.createTextOutput(JSON.stringify({ success: true, encryptedPayload: data })).setMimeType(ContentService.MimeType.JSON);
  }
}"""

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun DriveBackupSheet(
  driveLinks: List<UserDriveLink>,
  defaultBridgeUrl: String,
  autoSyncEnabled: Boolean,
  sessionPassphrase: String,
  lastSyncedAt: Long?,
  activeDriveLabel: String?,
  isBusy: Boolean,
  statusMessage: Pair<Boolean, String>?,
  onPassphraseChange: (String) -> Unit,
  onSaveDriveLink: (
    editingId: String?,
    label: String,
    scriptUrl: String,
    folderUrlOrId: String,
    dataScope: DriveDataScope,
    autoSubfolders: Boolean,
  ) -> Unit,
  onRemoveDriveLink: (String) -> Unit,
  onToggleDriveLink: (String, Boolean) -> Unit,
  onMovePriority: (String, Boolean) -> Unit,
  onSetAutoSync: (Boolean) -> Unit,
  onTestLink: (UserDriveLink) -> Unit,
  onSyncAll: (String) -> Unit,
  onRestoreFromLink: (UserDriveLink, String) -> Unit,
  onBuildVaultJson: suspend (String) -> String,
  onRestoreFromSafJson: (String, String) -> Unit,
  onDismiss: () -> Unit,
) {
  val context = LocalContext.current
  val glass = LocalGlassPalette.current
  val scope = rememberCoroutineScope()
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  var editingLinkId by remember { mutableStateOf<String?>(null) }
  var newLabel by remember { mutableStateOf("") }
  var newFolderUrl by remember { mutableStateOf("") }
  var newScriptUrl by remember { mutableStateOf(defaultBridgeUrl) }
  var selectedScope by remember { mutableStateOf(DriveDataScope.ALL_AUTO_SUBFOLDERS) }
  var autoSubfolders by remember { mutableStateOf(true) }
  var showGuide by remember { mutableStateOf(false) }

  LaunchedEffect(defaultBridgeUrl) {
    if (newScriptUrl.isBlank() && defaultBridgeUrl.isNotBlank()) {
      newScriptUrl = defaultBridgeUrl
    }
  }

  val exportSafLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
      if (uri != null) {
        scope.launch {
          try {
            val json = onBuildVaultJson(sessionPassphrase)
            withContext(Dispatchers.IO) {
              context.contentResolver.openOutputStream(uri)?.use { out ->
                out.write(json.toByteArray(Charsets.UTF_8))
              }
            }
            Toast.makeText(context, "এনক্রিপ্টেড ফাইল সেভ হয়েছে!", Toast.LENGTH_SHORT).show()
          } catch (e: Exception) {
            Toast.makeText(context, e.message ?: "সেভ করা যায়নি", Toast.LENGTH_LONG).show()
          }
        }
      }
    }

  val importSafLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
      if (uri != null) {
        scope.launch {
          try {
            val json =
              withContext(Dispatchers.IO) {
                context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                  ?: ""
              }
            onRestoreFromSafJson(json, sessionPassphrase)
          } catch (e: Exception) {
            Toast.makeText(context, e.message ?: "ফাইল পড়া যায়নি", Toast.LENGTH_LONG).show()
          }
        }
      }
    }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = glass.glassBarBg,
  ) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 20.dp)
          .navigationBarsPadding()
          .padding(bottom = 24.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          Icons.Default.CloudSync,
          contentDescription = "ড্রাইভ ব্যাকআপ",
          tint = glass.accent,
          modifier = Modifier.size(28.dp),
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = "গুগল ড্রাইভ লিংক ও ফোল্ডার ম্যানেজার",
            style = MaterialTheme.typography.titleLarge,
            color = glass.textPrimary,
          )
          Text(
            text = "সব ড্রাইভ লিংক যোগ, এডিট ও আলাদা ফোল্ডার রাউটিং",
            style = MaterialTheme.typography.bodyMedium,
            color = glass.textSecondary,
          )
        }
      }

      GlassPanelBox(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
          Icon(
            Icons.Default.Shield,
            contentDescription = "সিকিউরিটি",
            tint = ProfitGreen,
            modifier = Modifier.size(22.dp),
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text =
              "আপনার নিজের গুগল ড্রাইভ ফোল্ডারে AES-256 এনক্রিপ্টেড ভল্ট এবং আলাদা আলাদা ফোল্ডার সম্পূর্ণ Private অবস্থায় সেভ হবে।",
            style = MaterialTheme.typography.bodyMedium,
            color = glass.textPrimary,
          )
        }
      }

      OutlinedTextField(
        value = sessionPassphrase,
        onValueChange = onPassphraseChange,
        label = { Text("ভল্ট সিকিউরিটি পাসওয়ার্ড (AES-256 Key) *") },
        placeholder = { Text("কমপক্ষে ৪ অক্ষরের পাসওয়ার্ড দিন") },
        visualTransformation = PasswordVisualTransformation(),
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("vault_passphrase_input"),
      )

      // Add or Edit Drive Link Form
      GlassCard(innerPadding = 14.dp) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              Icons.Default.CreateNewFolder,
              contentDescription = "ফোল্ডার লিংক",
              tint = glass.accent,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (editingLinkId != null) "ড্রাইভ লিংক এডিট করুন" else "ড্রাইভ লিংক ও ফোল্ডার যোগ করুন",
              style = MaterialTheme.typography.titleMedium,
              color = glass.textPrimary,
            )
          }
          TextButton(
            onClick = { showGuide = !showGuide },
            modifier = Modifier.testTag("toggle_apps_script_guide"),
          ) {
            Icon(Icons.Default.Code, contentDescription = "গাইড", modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(if (showGuide) "লুকান" else "সেটআপ কোড")
          }
        }

        AnimatedVisibility(visible = showGuide) {
          Column(
            modifier = Modifier.padding(vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Text(
              text =
                "১. আপনার নিজের জিমেইল থেকে script.google.com-এ নতুন প্রজেক্ট খুলে নিচের কোডটি পেস্ট করুন।\n২. Deploy -> New deployment -> Web app (Who has access: Anyone) দিয়ে পাওয়া লিংকটি নিচে দিন।\n৩. এরপর যত খুশি আলাদা Google Drive ফোল্ডার লিংক যোগ করলেই ডাটা অটো সেখানে যাবে!",
              style = MaterialTheme.typography.bodyMedium,
              color = glass.textSecondary,
            )
            OutlinedButton(
              onClick = {
                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Apps Script", USER_APPS_SCRIPT_CODE))
                Toast.makeText(context, "অটো-ফোল্ডার Apps Script কোড কপি হয়েছে!", Toast.LENGTH_SHORT)
                  .show()
              },
              modifier = Modifier.testTag("copy_apps_script_button"),
            ) {
              Icon(Icons.Default.ContentCopy, contentDescription = "কপি", modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("অটো-ফোল্ডার Script কোড কপি করুন")
            }
          }
        }

        Spacer(modifier = Modifier.height(6.dp))

        OutlinedTextField(
          value = newLabel,
          onValueChange = { newLabel = it },
          label = { Text("ফোল্ডার / ড্রাইভের নাম (যেমন: দোকানের মূল ড্রাইভ)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("new_drive_label_input"),
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
          value = newFolderUrl,
          onValueChange = { newFolderUrl = it },
          label = { Text("গুগল ড্রাইভ ফোল্ডার লিংক (ঐচ্ছিক / আলাদা ফোল্ডার)") },
          placeholder = { Text("https://drive.google.com/drive/folders/...") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("new_drive_folder_input"),
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
          value = newScriptUrl,
          onValueChange = { newScriptUrl = it },
          label = { Text("আপনার Apps Script ব্রিজ লিংক *") },
          placeholder = { Text("https://script.google.com/macros/s/.../exec") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("new_drive_script_input"),
        )

        Spacer(modifier = Modifier.height(10.dp))
        Text(
          text = "এই ড্রাইভ ফোল্ডারে কোন ডাটা যাবে?",
          style = MaterialTheme.typography.labelLarge,
          color = glass.textPrimary,
        )
        Spacer(modifier = Modifier.height(6.dp))
        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          DriveDataScope.entries.forEach { scopeOption ->
            FilterChip(
              selected = selectedScope == scopeOption,
              onClick = { selectedScope = scopeOption },
              shape = RoundedCornerShape(50),
              colors =
                FilterChipDefaults.filterChipColors(
                  selectedContainerColor = glass.accent.copy(alpha = 0.18f),
                  selectedLabelColor = glass.accent,
                ),
              label = { Text(scopeOption.shortLabelBn) },
              modifier = Modifier.testTag("drive_scope_${scopeOption.name}"),
            )
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "ভেতরে আলাদা সাব-ফোল্ডার (Products, Sales, ShortList) তৈরি করুন",
            style = MaterialTheme.typography.labelSmall,
            color = glass.textSecondary,
            modifier = Modifier.weight(1f).padding(end = 8.dp),
          )
          Switch(
            checked = autoSubfolders,
            onCheckedChange = { autoSubfolders = it },
            modifier = Modifier.testTag("auto_subfolders_switch"),
          )
        }

        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          if (editingLinkId != null) {
            OutlinedButton(
              onClick = {
                editingLinkId = null
                newLabel = ""
                newFolderUrl = ""
                selectedScope = DriveDataScope.ALL_AUTO_SUBFOLDERS
                autoSubfolders = true
              },
              shape = RoundedCornerShape(14.dp),
              modifier = Modifier.height(48.dp),
            ) {
              Text("বাতিল")
            }
          }
          Button(
            onClick = {
              onSaveDriveLink(
                editingLinkId,
                newLabel,
                newScriptUrl,
                newFolderUrl,
                selectedScope,
                autoSubfolders,
              )
              if (newScriptUrl.trim().startsWith("https://script.google.com/macros/")) {
                editingLinkId = null
                newLabel = ""
                newFolderUrl = ""
              }
            },
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = glass.accent, contentColor = Color.White),
            modifier = Modifier.weight(1f).height(48.dp).testTag("add_drive_link_button"),
          ) {
            Icon(Icons.Default.AddLink, contentDescription = "যোগ করুন")
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              if (editingLinkId != null) "আপডেট সেভ করুন" else "ড্রাইভ ফোল্ডার লিংক যোগ করুন",
              fontWeight = FontWeight.Bold,
            )
          }
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "বিক্রি ও পণ্যের সাথে সাথে অটো-সিঙ্ক",
            style = MaterialTheme.typography.titleMedium,
            color = glass.textPrimary,
          )
          if (lastSyncedAt != null) {
            val timeStr =
              SimpleDateFormat("dd MMM, hh:mm a", Locale.US).format(Date(lastSyncedAt))
            Text(
              text = "সর্বশেষ: ${activeDriveLabel ?: "ড্রাইভ"} ($timeStr)",
              style = MaterialTheme.typography.labelSmall,
              color = glass.textSecondary,
            )
          }
        }
        Switch(
          checked = autoSyncEnabled,
          onCheckedChange = onSetAutoSync,
          modifier = Modifier.testTag("auto_sync_switch"),
        )
      }

      Text(
        text = "যুক্ত করা গুগল ড্রাইভ ফোল্ডারসমূহ (${driveLinks.size}টি)",
        style = MaterialTheme.typography.titleMedium,
        color = glass.textPrimary,
      )

      if (driveLinks.isEmpty()) {
        GlassPanelBox(modifier = Modifier.fillMaxWidth()) {
          Text(
            text = "এখনো কোনো ড্রাইভ লিংক যোগ করা হয়নি। উপরে আপনার ফোল্ডার লিংক যোগ করুন অথবা নিচের বাটন দিয়ে সরাসরি ফোনের Google Drive অ্যাপে সেভ করুন।",
            style = MaterialTheme.typography.bodyMedium,
            color = glass.textSecondary,
            modifier = Modifier.padding(14.dp),
          )
        }
      } else {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          driveLinks.forEachIndexed { index, link ->
            GlassPanelBox(modifier = Modifier.fillMaxWidth()) {
              Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                      shape = RoundedCornerShape(8.dp),
                      color = glass.accent.copy(alpha = 0.16f),
                    ) {
                      Text(
                        text = "#${index + 1}",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        color = glass.accent,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                      )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                      Text(
                        text = link.label,
                        style = MaterialTheme.typography.titleMedium,
                        color = glass.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                      )
                      Text(
                        text = link.dataScope.shortLabelBn,
                        style = MaterialTheme.typography.labelSmall,
                        color = glass.accent,
                      )
                    }
                  }
                  Switch(
                    checked = link.enabled,
                    onCheckedChange = { onToggleDriveLink(link.id, it) },
                    modifier = Modifier.testTag("toggle_drive_${link.id}"),
                  )
                }

                if (link.driveFolderUrl.isNotBlank()) {
                  Text(
                    text = "ফোল্ডার: ${link.driveFolderUrl}",
                    fontFamily = JetBrainsMonoFontFamily,
                    style = MaterialTheme.typography.labelSmall,
                    color = glass.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                }

                val badgeColor =
                  when (link.status) {
                    DriveLinkStatus.SYNCED -> ProfitGreen
                    DriveLinkStatus.QUOTA_FULL -> WarningAmber
                    DriveLinkStatus.ERROR -> DangerRose
                    DriveLinkStatus.READY -> glass.accent
                  }

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = badgeColor.copy(alpha = 0.16f),
                  ) {
                    Text(
                      text = link.status.labelBn,
                      style = MaterialTheme.typography.labelSmall,
                      fontWeight = FontWeight.Bold,
                      color = badgeColor,
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                    )
                  }
                }

                FlowRow(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(2.dp),
                  verticalArrangement = Arrangement.Center,
                ) {
                  IconButton(
                    onClick = {
                      editingLinkId = link.id
                      newLabel = link.label
                      newFolderUrl = link.driveFolderUrl
                      newScriptUrl = link.scriptEndpointUrl
                      selectedScope = link.dataScope
                      autoSubfolders = link.autoSubfolders
                    },
                    modifier = Modifier.testTag("edit_drive_${link.id}"),
                  ) {
                    Icon(Icons.Default.Edit, contentDescription = "এডিট করুন")
                  }
                  IconButton(
                    enabled = !isBusy,
                    onClick = { onTestLink(link) },
                    modifier = Modifier.testTag("test_drive_${link.id}"),
                  ) {
                    Icon(Icons.Default.WifiTethering, contentDescription = "লিংক টেস্ট")
                  }
                  IconButton(
                    enabled = !isBusy && sessionPassphrase.length >= 4,
                    onClick = { onRestoreFromLink(link, sessionPassphrase) },
                    modifier = Modifier.testTag("restore_drive_${link.id}"),
                  ) {
                    Icon(Icons.Default.Download, contentDescription = "রিস্টোর")
                  }
                  IconButton(
                    enabled = index > 0,
                    onClick = { onMovePriority(link.id, true) },
                  ) {
                    Icon(Icons.Default.ArrowUpward, contentDescription = "উপরে নিন")
                  }
                  IconButton(
                    enabled = index < driveLinks.lastIndex,
                    onClick = { onMovePriority(link.id, false) },
                  ) {
                    Icon(Icons.Default.ArrowDownward, contentDescription = "নিচে নিন")
                  }
                  IconButton(onClick = { onRemoveDriveLink(link.id) }) {
                    Icon(Icons.Default.Delete, contentDescription = "মুছে ফেলুন", tint = DangerRose)
                  }
                }

                if (link.lastError.isNotBlank()) {
                  Text(
                    text = link.lastError,
                    style = MaterialTheme.typography.labelSmall,
                    color = DangerRose,
                  )
                }
              }
            }
          }
        }
      }

      Button(
        enabled = !isBusy && sessionPassphrase.length >= 4 && driveLinks.any { it.enabled },
        onClick = { onSyncAll(sessionPassphrase) },
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = glass.accent, contentColor = Color.White),
        modifier = Modifier.fillMaxWidth().height(50.dp).testTag("sync_all_drives_button"),
      ) {
        Icon(Icons.Default.CloudSync, contentDescription = "সিঙ্ক করুন")
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          if (isBusy) "সিঙ্ক হচ্ছে..." else "সকল ফোল্ডারে এখনই ব্যাকআপ দিন",
          fontWeight = FontWeight.Bold,
        )
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        OutlinedButton(
          enabled = !isBusy && sessionPassphrase.length >= 4,
          onClick = { exportSafLauncher.launch("smart-dokan-vault.enc.json") },
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.weight(1f).testTag("saf_export_button"),
        ) {
          Icon(Icons.Default.SaveAlt, contentDescription = "ফাইল সেভ", modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("ফাইলে সেভ (Drive)", maxLines = 1)
        }
        OutlinedButton(
          enabled = !isBusy && sessionPassphrase.length >= 4,
          onClick = { importSafLauncher.launch(arrayOf("application/json", "*/*")) },
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.weight(1f).testTag("saf_import_button"),
        ) {
          Icon(Icons.Default.FolderOpen, contentDescription = "ফাইল রিস্টোর", modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("ফাইল রিস্টোর", maxLines = 1)
        }
      }

      if (statusMessage != null) {
        val (isErr, text) = statusMessage
        Surface(
          shape = RoundedCornerShape(14.dp),
          color = (if (isErr) DangerRose else ProfitGreen).copy(alpha = 0.16f),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = if (isErr) DangerRose else ProfitGreen,
            modifier = Modifier.padding(12.dp),
          )
        }
      }
    }
  }
}
