package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.ProductEntity
import com.example.data.prefs.ShopProfile
import com.example.ui.components.GlassCard
import com.example.ui.components.GlassPanelBox
import com.example.ui.components.GlassTintedIconButton
import com.example.ui.theme.DangerRose
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalGlassPalette
import com.example.ui.theme.WarningAmber

@Composable
fun ShortListScreen(
  products: List<ProductEntity>,
  shopProfile: ShopProfile,
  onQuickRestock: (ProductEntity) -> Unit,
  onEditProduct: (ProductEntity) -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val glass = LocalGlassPalette.current
  val cur = shopProfile.currencySymbol
  val threshold = shopProfile.lowStockThreshold
  val lowItems = remember(products, threshold) { products.filter { it.stock <= threshold }.sortedBy { it.stock } }

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 92.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item {
      GlassCard(innerPadding = 16.dp) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
            Icon(
              Icons.Default.Warning,
              contentDescription = "শর্ট লিস্ট",
              tint = WarningAmber,
              modifier = Modifier.size(26.dp),
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "শর্ট লিস্ট (স্টক $threshold বা তার কম)",
                style = MaterialTheme.typography.titleMedium,
                color = glass.textPrimary,
              )
              Text(
                text = "পাইকারি অর্ডারের স্বয়ংক্রিয় তালিকা",
                style = MaterialTheme.typography.bodyMedium,
                color = glass.textSecondary,
              )
            }
          }

          if (lowItems.isNotEmpty()) {
            OutlinedButton(
              onClick = {
                val text =
                  buildString {
                    appendLine("${shopProfile.shopName} — শর্ট লিস্ট:")
                    lowItems.forEachIndexed { idx, p ->
                      val brand = if (p.brandName.isNotBlank()) " (${p.brandName})" else ""
                      appendLine("${idx + 1}. ${p.name}$brand — বাকি স্টক: ${p.stock}")
                    }
                  }
                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Short List", text))
                Toast.makeText(context, "শর্ট লিস্ট কপি হয়েছে!", Toast.LENGTH_SHORT).show()
              },
              shape = RoundedCornerShape(50),
              modifier = Modifier.testTag("copy_shortlist_button"),
            ) {
              Icon(Icons.Default.ContentCopy, contentDescription = "কপি", modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("কপি")
            }
          }
        }
      }
    }

    if (lowItems.isEmpty()) {
      item {
        GlassCard(innerPadding = 28.dp) {
          Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text(
              text = "চমৎকার! আপনার সব পণ্যের পর্যাপ্ত স্টক রয়েছে।",
              style = MaterialTheme.typography.titleMedium,
              color = glass.textPrimary,
            )
          }
        }
      }
    } else {
      items(lowItems, key = { it.id }) { p ->
        GlassPanelBox(modifier = Modifier.fillMaxWidth()) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
              Text(
                text = p.name,
                style = MaterialTheme.typography.titleMedium,
                color = glass.textPrimary,
              )
              val info =
                listOf(p.brandName, p.boxLocation).filter { it.isNotBlank() }.joinToString(" • ")
              if (info.isNotBlank()) {
                Text(
                  text = info,
                  style = MaterialTheme.typography.labelSmall,
                  color = glass.textSecondary,
                )
              }
              Text(
                text = "কেনা দাম: $cur${p.buyingPrice} • বাকি স্টক: ${p.stock}",
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodyMedium,
                color = if (p.stock == 0) DangerRose else WarningAmber,
              )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
              GlassTintedIconButton(
                icon = Icons.Default.Edit,
                contentDescription = "এডিট",
                tint = glass.accent,
                onClick = { onEditProduct(p) },
              )
              Button(
                onClick = { onQuickRestock(p) },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = glass.accent, contentColor = Color.White),
                modifier = Modifier.testTag("shortlist_restock_${p.id}"),
              ) {
                Icon(Icons.Default.AddShoppingCart, contentDescription = "+১০ স্টক", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("+10")
              }
            }
          }
        }
      }
    }
  }
}
