package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.SaleEntity
import com.example.ui.theme.DangerRose
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalGlassPalette
import com.example.ui.theme.ProfitGreen
import java.util.Locale

@Composable
fun SaleEditDialog(
  sale: SaleEntity,
  currencySymbol: String,
  onDismiss: () -> Unit,
  onSave: (saleId: Long, newQty: Int, newBuy: Double, newSell: Double, newDateKey: String) -> Unit,
) {
  val glass = LocalGlassPalette.current
  var qtyText by remember(sale) { mutableStateOf(sale.quantity.toString()) }
  var buyText by remember(sale) { mutableStateOf(sale.buyingPriceAtSale.toString()) }
  var sellText by remember(sale) { mutableStateOf(sale.sellingPriceAtSale.toString()) }
  var dateKey by remember(sale) { mutableStateOf(sale.dateKey) }

  val qty = (qtyText.toIntOrNull() ?: 1).coerceAtLeast(1)
  val buy = buyText.toDoubleOrNull() ?: 0.0
  val sell = sellText.toDoubleOrNull() ?: 0.0
  val newProfit = (sell - buy) * qty

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false),
  ) {
    GlassCard(
      modifier = Modifier.fillMaxWidth(0.92f).padding(vertical = 16.dp),
      shape = RoundedCornerShape(26.dp),
      innerPadding = 18.dp,
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.ReceiptLong, contentDescription = "বিক্রি এডিট", tint = glass.accent)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "বিক্রয় হিসাব এডিট করুন",
            style = MaterialTheme.typography.titleLarge,
            color = glass.textPrimary,
          )
        }
        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "বন্ধ করুন", tint = glass.textPrimary)
        }
      }

      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = sale.productName,
        style = MaterialTheme.typography.titleMedium,
        color = glass.accent,
      )
      Spacer(modifier = Modifier.height(10.dp))

      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          OutlinedTextField(
            value = qtyText,
            onValueChange = { qtyText = it.filter { c -> c.isDigit() } },
            label = { Text("পরিমাণ") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.weight(0.8f).testTag("sale_edit_qty_input"),
          )
          OutlinedTextField(
            value = buyText,
            onValueChange = { buyText = it },
            label = { Text("কেনা দাম") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.weight(1f).testTag("sale_edit_buy_input"),
          )
          OutlinedTextField(
            value = sellText,
            onValueChange = { sellText = it },
            label = { Text("বিক্রয় মূল্য") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.weight(1f).testTag("sale_edit_sell_input"),
          )
        }

        OutlinedTextField(
          value = dateKey,
          onValueChange = { dateKey = it },
          label = { Text("তারিখ (YYYY-MM-DD)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("sale_edit_date_input"),
        )

        GlassPanelBox(modifier = Modifier.fillMaxWidth()) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text(
              text = String.format(Locale.US, "মোট: %s%.2f", currencySymbol, sell * qty),
              fontFamily = JetBrainsMonoFontFamily,
              fontWeight = FontWeight.Bold,
              color = glass.textPrimary,
            )
            Text(
              text = String.format(Locale.US, "লাভ: %s%.2f", currencySymbol, newProfit),
              fontFamily = JetBrainsMonoFontFamily,
              fontWeight = FontWeight.Bold,
              color = if (newProfit >= 0) ProfitGreen else DangerRose,
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        OutlinedButton(onClick = onDismiss) { Text("বাতিল") }
        Spacer(modifier = Modifier.width(10.dp))
        Button(
          onClick = {
            onSave(sale.id, qty, buy, sell, dateKey.trim())
            onDismiss()
          },
          colors = ButtonDefaults.buttonColors(containerColor = glass.accent, contentColor = Color.White),
          modifier = Modifier.testTag("save_sale_edit_button"),
        ) {
          Text("হিসাব আপডেট করুন", fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}
