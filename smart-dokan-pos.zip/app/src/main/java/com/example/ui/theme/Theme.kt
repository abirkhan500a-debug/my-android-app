package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.example.data.prefs.BlurIntensity
import com.example.data.prefs.ThemeConfig

@Immutable
data class GlassPalette(
  val isDark: Boolean,
  val accent: Color,
  val secondaryAccent: Color,
  val bgStart: Color,
  val bgMid: Color,
  val bgEnd: Color,
  val glassCardBg: Color,
  val glassBarBg: Color,
  val glassBorder: Color,
  val glassInnerBg: Color,
  val textPrimary: Color,
  val textSecondary: Color,
  val blurIntensity: BlurIntensity,
)

val LocalGlassPalette =
  staticCompositionLocalOf {
    GlassPalette(
      isDark = false,
      accent = EmeraldPrimary,
      secondaryAccent = Color(0xFF0D9488),
      bgStart = Color(0xFFD1FAE5),
      bgMid = Color(0xFFECFDF5),
      bgEnd = Color(0xFFCCFBF1),
      glassCardBg = Color.White.copy(alpha = 0.72f),
      glassBarBg = Color.White.copy(alpha = 0.65f),
      glassBorder = Color.White.copy(alpha = 0.55f),
      glassInnerBg = Color.White.copy(alpha = 0.45f),
      textPrimary = Color(0xFF064E3B),
      textSecondary = Color(0xFF047857),
      blurIntensity = BlurIntensity.MEDIUM,
    )
  }

@Composable
fun SmartDokanTheme(
  themeConfig: ThemeConfig = ThemeConfig(),
  content: @Composable () -> Unit,
) {
  val preset = themeConfig.preset
  val accent = Color(themeConfig.customAccentHex)
  val secondary = Color(preset.secondaryAccentHex)
  val bgStart = Color(themeConfig.customBgStartHex)
  val bgMid = Color(preset.bgMidHex)
  val bgEnd = Color(themeConfig.customBgEndHex)

  val cardAlpha =
    if (preset.isDark) themeConfig.blurIntensity.cardAlphaDark
    else themeConfig.blurIntensity.cardAlphaLight

  val glassPalette =
    if (preset.isDark) {
      GlassPalette(
        isDark = true,
        accent = accent,
        secondaryAccent = secondary,
        bgStart = bgStart,
        bgMid = bgMid,
        bgEnd = bgEnd,
        glassCardBg = Color(0xFF1E293B).copy(alpha = cardAlpha),
        glassBarBg = Color(0xFF0F172A).copy(alpha = (cardAlpha + 0.14f).coerceAtMost(0.9f)),
        glassBorder = Color.White.copy(alpha = 0.18f),
        glassInnerBg = Color(0xFF0F172A).copy(alpha = 0.48f),
        textPrimary = Color(0xFFF8FAFC),
        textSecondary = Color(0xFFCBD5E1),
        blurIntensity = themeConfig.blurIntensity,
      )
    } else {
      GlassPalette(
        isDark = false,
        accent = accent,
        secondaryAccent = secondary,
        bgStart = bgStart,
        bgMid = bgMid,
        bgEnd = bgEnd,
        glassCardBg = Color.White.copy(alpha = cardAlpha),
        glassBarBg = Color.White.copy(alpha = (cardAlpha + 0.08f).coerceAtMost(0.92f)),
        glassBorder = Color.White.copy(alpha = 0.62f),
        glassInnerBg = Color.White.copy(alpha = 0.46f),
        textPrimary = Color(0xFF0F172A),
        textSecondary = Color(0xFF334155),
        blurIntensity = themeConfig.blurIntensity,
      )
    }

  val colorScheme =
    if (preset.isDark) {
      darkColorScheme(
        primary = accent,
        onPrimary = Color.White,
        secondary = secondary,
        background = bgStart,
        surface = Color(0xFF0F172A),
        onBackground = Color(0xFFF8FAFC),
        onSurface = Color(0xFFF8FAFC),
        surfaceVariant = Color(0xFF1E293B),
        onSurfaceVariant = Color(0xFFCBD5E1),
      )
    } else {
      lightColorScheme(
        primary = accent,
        onPrimary = Color.White,
        secondary = secondary,
        background = bgMid,
        surface = Color.White,
        onBackground = Color(0xFF0F172A),
        onSurface = Color(0xFF0F172A),
        surfaceVariant = bgStart,
        onSurfaceVariant = Color(0xFF334155),
      )
    }

  CompositionLocalProvider(LocalGlassPalette provides glassPalette) {
    MaterialTheme(colorScheme = colorScheme, typography = AppTypography, content = content)
  }
}
