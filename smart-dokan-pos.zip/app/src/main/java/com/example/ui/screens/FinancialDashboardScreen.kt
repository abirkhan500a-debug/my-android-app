package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.ProductEntity
import com.example.data.local.SaleEntity
import com.example.data.prefs.ShopProfile
import com.example.ui.ReportPeriod
import com.example.ui.components.DailyChartPoint
import com.example.ui.components.GlassCard
import com.example.ui.components.GlassPanelBox
import com.example.ui.components.GlassTintedIconButton
import com.example.ui.components.WeeklyProfitBarChart
import com.example.ui.theme.DangerRose
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalGlassPalette
import com.example.ui.theme.ProfitGreen
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

private data class ProductBreakdownRow(
  val productId: Long,
  val productName: String,
  val qty: Int,
  val revenue: Double,
  val cost: Double,
  val profit: Double,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinancialDashboardScreen(
  sales: List<SaleEntity>,
  products: List<ProductEntity>,
  shopProfile: ShopProfile,
  onEditShopProfile: () -> Unit,
  onEditSale: (SaleEntity) -> Unit,
  onDeleteSale: (SaleEntity) -> Unit,
  onEditProductById: (Long) -> Unit,
  modifier: Modifier = Modifier,
) {
  val glass = LocalGlassPalette.current
  val cur = shopProfile.currencySymbol
  val sdf = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
  val shortDayFmt = remember { SimpleDateFormat("dd/MM", Locale.US) }
  var selectedDateKey by remember { mutableStateOf(sdf.format(Date())) }
  var period by remember { mutableStateOf(ReportPeriod.DAILY) }
  var showDatePicker by remember { mutableStateOf(false) }

  val totalStockValue = remember(products) { products.sumOf { it.buyingPrice * it.stock } }
  val totalUnits = remember(products) { products.sumOf { it.stock } }

  val filteredSales =
    remember(sales, selectedDateKey, period) {
      val anchorDate = runCatching { sdf.parse(selectedDateKey) }.getOrNull() ?: Date()
      sales.filter { s ->
        when (period) {
          ReportPeriod.DAILY -> s.dateKey == selectedDateKey
          ReportPeriod.WEEKLY -> {
            val sDate = runCatching { sdf.parse(s.dateKey) }.getOrNull() ?: return@filter false
            val diffDays = ((anchorDate.time - sDate.time) / 86_400_000L).toInt()
            diffDays in 0..6
          }
          ReportPeriod.MONTHLY -> s.dateKey.take(7) == selectedDateKey.take(7)
        }
      }
    }

  val totalRevenue = remember(filteredSales) { filteredSales.sumOf { it.totalRevenue } }
  val totalCost = remember(filteredSales) { filteredSales.sumOf { it.totalCost } }
  val totalProfit = remember(filteredSales) { filteredSales.sumOf { it.netProfit } }
  val totalQty = remember(filteredSales) { filteredSales.sumOf { it.quantity } }

  val chartPoints =
    remember(sales, selectedDateKey) {
      val anchor = runCatching { sdf.parse(selectedDateKey) }.getOrNull() ?: Date()
      val cal = Calendar.getInstance()
      (6 downTo 0).map { offset ->
        cal.time = anchor
        cal.add(Calendar.DAY_OF_YEAR, -offset)
        val key = sdf.format(cal.time)
        val label = shortDayFmt.format(cal.time)
        val daySales = sales.filter { it.dateKey == key }
        DailyChartPoint(
          dayLabel = label,
          revenue = daySales.sumOf { it.totalRevenue },
          profit = daySales.sumOf { it.netProfit },
        )
      }
    }

  val breakdown =
    remember(filteredSales) {
      filteredSales
        .groupBy { it.productId }
        .map { (prodId, items) ->
          ProductBreakdownRow(
            productId = prodId,
            productName = items.first().productName,
            qty = items.sumOf { it.quantity },
            revenue = items.sumOf { it.totalRevenue },
            cost = items.sumOf { it.totalCost },
            profit = items.sumOf { it.netProfit },
          )
        }
        .sortedByDescending { it.profit }
    }
  val maxItemProfit = breakdown.maxOfOrNull { it.profit.coerceAtLeast(0.0) }?.coerceAtLeast(1.0) ?: 1.0

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 92.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    // Editable Shop Profile & Inventory Valuation Card
    item {
      GlassCard(innerPadding = 16.dp) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.Top,
        ) {
          Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = RoundedCornerShape(14.dp),
              color = glass.accent.copy(alpha = 0.16f),
              modifier = Modifier.size(44.dp),
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Storefront, contentDescription = "দোকান", tint = glass.accent)
              }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = shopProfile.shopName,
                style = MaterialTheme.typography.titleLarge,
                color = glass.textPrimary,
              )
              if (shopProfile.shopSubtitle.isNotBlank()) {
                Text(
                  text = shopProfile.shopSubtitle,
                  style = MaterialTheme.typography.bodyMedium,
                  color = glass.textSecondary,
                )
              }
              val contact =
                listOf(shopProfile.phone, shopProfile.address)
                  .filter { it.isNotBlank() }
                  .joinToString(" • ")
              if (contact.isNotBlank()) {
                Text(
                  text = contact,
                  style = MaterialTheme.typography.labelSmall,
                  color = glass.textSecondary,
                )
              }
            }
          }
          GlassTintedIconButton(
            icon = Icons.Default.Edit,
            contentDescription = "দোকানের তথ্য এডিট",
            tint = glass.accent,
            onClick = onEditShopProfile,
            modifier = Modifier.testTag("edit_shop_profile_button"),
          )
        }

        Spacer(modifier = Modifier.height(10.dp))
        GlassPanelBox(modifier = Modifier.fillMaxWidth()) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Column {
              Text("মোট পণ্য ও স্টক", style = MaterialTheme.typography.labelSmall, color = glass.textSecondary)
              Text(
                text = "${products.size} ধরন ($totalUnits পিস)",
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold,
                color = glass.textPrimary,
              )
            }
            Column(horizontalAlignment = Alignment.End) {
              Text("মোট স্টকের কেনা মূল্য", style = MaterialTheme.typography.labelSmall, color = glass.textSecondary)
              Text(
                text = String.format(Locale.US, "%s %.2f", cur, totalStockValue),
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold,
                color = glass.accent,
              )
            }
          }
        }
      }
    }

    // Period & Date Controls
    item {
      GlassCard(innerPadding = 14.dp) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "আয়-ব্যয় ও লাভের ড্যাশবোর্ড",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = glass.textPrimary,
            modifier = Modifier.weight(1f).padding(end = 8.dp),
          )
          OutlinedButton(
            onClick = { showDatePicker = true },
            shape = RoundedCornerShape(50),
            modifier = Modifier.testTag("dashboard_date_picker_button"),
          ) {
            Icon(Icons.Default.CalendarMonth, contentDescription = "তারিখ")
            Spacer(modifier = Modifier.width(6.dp))
            Text(selectedDateKey, fontFamily = JetBrainsMonoFontFamily)
          }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          ReportPeriod.entries.forEach { p ->
            FilterChip(
              selected = period == p,
              onClick = { period = p },
              shape = RoundedCornerShape(50),
              colors =
                FilterChipDefaults.filterChipColors(
                  selectedContainerColor = glass.accent.copy(alpha = 0.18f),
                  selectedLabelColor = glass.accent,
                ),
              label = { Text(p.labelBn) },
              modifier = Modifier.testTag("period_chip_${p.name}"),
            )
          }
        }
      }
    }

    // Financial Summary Cards
    item {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          GlassCard(modifier = Modifier.weight(1f), innerPadding = 14.dp) {
            Text(
              text = "${period.labelBn} মোট বিক্রি",
              style = MaterialTheme.typography.labelLarge,
              color = glass.textSecondary,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = String.format(Locale.US, "%s %.2f", cur, totalRevenue),
              fontFamily = JetBrainsMonoFontFamily,
              fontWeight = FontWeight.Bold,
              style = MaterialTheme.typography.titleLarge,
              color = glass.textPrimary,
            )
            Text(
              text = "$totalQty পিস বিক্রি হয়েছে",
              style = MaterialTheme.typography.labelSmall,
              color = glass.textSecondary,
            )
          }

          GlassCard(modifier = Modifier.weight(1f), innerPadding = 14.dp) {
            Text(
              text = "${period.labelBn} আসল খরচ",
              style = MaterialTheme.typography.labelLarge,
              color = glass.textSecondary,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = String.format(Locale.US, "%s %.2f", cur, totalCost),
              fontFamily = JetBrainsMonoFontFamily,
              fontWeight = FontWeight.Bold,
              style = MaterialTheme.typography.titleLarge,
              color = glass.textPrimary,
            )
            Text(
              text = "কোম্পানি / কেনা দাম",
              style = MaterialTheme.typography.labelSmall,
              color = glass.textSecondary,
            )
          }
        }

        GlassCard(accentHighlight = glass.accent, innerPadding = 16.dp) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column {
              Text(
                text = "${period.labelBn} নিট লাভ",
                style = MaterialTheme.typography.titleMedium,
                color = glass.accent,
              )
              Text(
                text = String.format(Locale.US, "%s %.2f", cur, totalProfit),
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.ExtraBold,
                style = MaterialTheme.typography.headlineMedium,
                color = glass.accent,
              )
            }
            Icon(
              Icons.Default.TrendingUp,
              contentDescription = "নিট লাভ",
              tint = glass.accent,
              modifier = Modifier.size(30.dp),
            )
          }
        }
      }
    }

    // 7-Day Visual Chart
    item {
      GlassCard(innerPadding = 16.dp) {
        WeeklyProfitBarChart(points = chartPoints)
      }
    }

    // Product Breakdown Section
    item {
      Text(
        text = "পণ্য ভিত্তিক বিক্রয় ও লাভের বিবরণ",
        style = MaterialTheme.typography.titleMedium,
        color = glass.textPrimary,
        modifier = Modifier.padding(top = 4.dp),
      )
    }

    if (breakdown.isEmpty()) {
      item {
        GlassCard(innerPadding = 22.dp) {
          Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text(
              text = "নির্বাচিত সময়ে কোনো বিক্রয়ের তথ্য পাওয়া যায়নি।",
              style = MaterialTheme.typography.bodyMedium,
              color = glass.textSecondary,
            )
          }
        }
      }
    } else {
      itemsIndexed(breakdown, key = { _, item -> item.productId }) { idx, row ->
        val ratio = (row.profit.coerceAtLeast(0.0) / maxItemProfit).toFloat().coerceIn(0.05f, 1f)
        GlassPanelBox(modifier = Modifier.fillMaxWidth()) {
          Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Surface(
                  shape = CircleShape,
                  color = glass.accent.copy(alpha = 0.16f),
                  modifier = Modifier.size(28.dp),
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    Text(
                      text = "${idx + 1}",
                      fontFamily = JetBrainsMonoFontFamily,
                      fontWeight = FontWeight.Bold,
                      style = MaterialTheme.typography.labelSmall,
                      color = glass.accent,
                    )
                  }
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                  Text(
                    text = row.productName,
                    style = MaterialTheme.typography.titleMedium,
                    color = glass.textPrimary,
                  )
                  Text(
                    text =
                      String.format(
                        Locale.US,
                        "বিক্রি: %d পিস • মোট %s%.1f • খরচ %s%.1f",
                        row.qty,
                        cur,
                        row.revenue,
                        cur,
                        row.cost,
                      ),
                    fontFamily = JetBrainsMonoFontFamily,
                    style = MaterialTheme.typography.labelSmall,
                    color = glass.textSecondary,
                  )
                }
              }
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                  text = String.format(Locale.US, "+ %s%.2f", cur, row.profit),
                  fontFamily = JetBrainsMonoFontFamily,
                  fontWeight = FontWeight.Bold,
                  color = ProfitGreen,
                )
                GlassTintedIconButton(
                  icon = Icons.Default.Edit,
                  contentDescription = "পণ্য এডিট",
                  tint = glass.accent,
                  onClick = { onEditProductById(row.productId) },
                )
              }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Box(
              modifier =
                Modifier.fillMaxWidth()
                  .height(6.dp)
                  .clip(RoundedCornerShape(50))
                  .background(glass.glassBorder.copy(alpha = 0.35f))
            ) {
              Box(
                modifier =
                  Modifier.fillMaxWidth(ratio)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(50))
                    .background(glass.accent)
              )
            }
          }
        }
      }
    }

    // Editable Recent Sales Transactions Section
    if (filteredSales.isNotEmpty()) {
      item {
        Text(
          text = "বিক্রয় লেনদেন (যেকোনোটি এডিট বা বাতিল করুন)",
          style = MaterialTheme.typography.titleMedium,
          color = glass.textPrimary,
          modifier = Modifier.padding(top = 6.dp),
        )
      }

      items(filteredSales, key = { it.id }) { sale ->
        val timeFmt = remember { SimpleDateFormat("hh:mm a", Locale.US) }
        GlassPanelBox(modifier = Modifier.fillMaxWidth()) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
              Text(
                text = "${sale.productName} (${sale.quantity} পিস)",
                style = MaterialTheme.typography.titleMedium,
                color = glass.textPrimary,
              )
              Text(
                text =
                  String.format(
                    Locale.US,
                    "%s • %s • মোট %s%.1f • লাভ %s%.1f",
                    sale.dateKey,
                    timeFmt.format(Date(sale.timestamp)),
                    cur,
                    sale.totalRevenue,
                    cur,
                    sale.netProfit,
                  ),
                fontFamily = JetBrainsMonoFontFamily,
                style = MaterialTheme.typography.labelSmall,
                color = glass.textSecondary,
              )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              GlassTintedIconButton(
                icon = Icons.Default.Edit,
                contentDescription = "বিক্রি এডিট",
                tint = glass.accent,
                onClick = { onEditSale(sale) },
                modifier = Modifier.testTag("edit_sale_${sale.id}"),
              )
              GlassTintedIconButton(
                icon = Icons.Default.Delete,
                contentDescription = "বিক্রি বাতিল ও স্টক ফেরত",
                tint = DangerRose,
                onClick = { onDeleteSale(sale) },
                modifier = Modifier.testTag("delete_sale_${sale.id}"),
              )
            }
          }
        }
      }
    }
  }

  if (showDatePicker) {
    val pickerState = rememberDatePickerState()
    DatePickerDialog(
      onDismissRequest = { showDatePicker = false },
      confirmButton = {
        TextButton(
          onClick = {
            pickerState.selectedDateMillis?.let { millis ->
              val utcFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
              }
              selectedDateKey = utcFmt.format(Date(millis))
            }
            showDatePicker = false
          }
        ) { Text("ঠিক আছে") }
      },
      dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("বাতিল") } },
    ) {
      DatePicker(state = pickerState)
    }
  }
}
