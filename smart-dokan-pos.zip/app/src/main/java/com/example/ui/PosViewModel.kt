package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.PosDatabase
import com.example.data.local.PosRepository
import com.example.data.local.ProductEntity
import com.example.data.local.SaleEntity
import com.example.data.prefs.BlurIntensity
import com.example.data.prefs.DriveDataScope
import com.example.data.prefs.DriveLinkParser
import com.example.data.prefs.DriveLinkStatus
import com.example.data.prefs.MeshStyle
import com.example.data.prefs.PreferencesManager
import com.example.data.prefs.ShopProfile
import com.example.data.prefs.ThemeConfig
import com.example.data.prefs.ThemePreset
import com.example.data.prefs.UserDriveLink
import com.example.data.sync.MultiDriveSyncManager
import com.example.util.ImageStorageHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class SyncVisualState {
  IDLE,
  SYNCING,
  SYNCED,
  ERROR,
}

enum class InventoryFilter(val labelBn: String) {
  ALL("সব পণ্য"),
  LOW_STOCK("কম স্টক"),
  EXPIRING("মেয়াদ সতর্কতা"),
}

enum class ReportPeriod(val labelBn: String) {
  DAILY("দৈনিক"),
  WEEKLY("সাপ্তাহিক"),
  MONTHLY("মাসিক"),
}

class PosViewModel(application: Application) : AndroidViewModel(application) {
  private val dao = PosDatabase.getInstance(application).posDao()
  private val repository = PosRepository(dao)
  private val prefs = PreferencesManager(application)
  private val syncManager = MultiDriveSyncManager(application, repository, prefs)

  val products: StateFlow<List<ProductEntity>> =
    repository.products.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val sales: StateFlow<List<SaleEntity>> =
    repository.sales.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val themeConfig: StateFlow<ThemeConfig> =
    prefs.themeConfig.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ThemeConfig())

  val shopProfile: StateFlow<ShopProfile> =
    prefs.shopProfile.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ShopProfile())

  val driveLinks: StateFlow<List<UserDriveLink>> =
    prefs.driveLinks.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val defaultBridgeUrl: StateFlow<String> =
    prefs.defaultBridgeUrl.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

  val autoSyncEnabled: StateFlow<Boolean> =
    prefs.autoSyncEnabled.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

  val lastSyncedAt: StateFlow<Long?> =
    prefs.lastSyncedAt.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  val activeDriveLabel: StateFlow<String?> =
    prefs.activeDriveLabel.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  private val _inventoryFilter = MutableStateFlow(InventoryFilter.ALL)
  val inventoryFilter: StateFlow<InventoryFilter> = _inventoryFilter.asStateFlow()

  private val _syncState = MutableStateFlow(SyncVisualState.IDLE)
  val syncState: StateFlow<SyncVisualState> = _syncState.asStateFlow()

  private val _isOnline = MutableStateFlow(syncManager.isOnline())
  val isOnline: StateFlow<Boolean> = _isOnline.asStateFlow()

  private val _sessionPassphrase = MutableStateFlow("")
  val sessionPassphrase: StateFlow<String> = _sessionPassphrase.asStateFlow()

  private val _driveStatusMessage = MutableStateFlow<Pair<Boolean, String>?>(null)
  val driveStatusMessage: StateFlow<Pair<Boolean, String>?> = _driveStatusMessage.asStateFlow()

  private val _driveBusy = MutableStateFlow(false)
  val driveBusy: StateFlow<Boolean> = _driveBusy.asStateFlow()

  private val _toastEvents = MutableSharedFlow<Pair<Boolean, String>>()
  val toastEvents = _toastEvents.asSharedFlow()

  val filteredProducts: StateFlow<List<ProductEntity>> =
    combine(products, _searchQuery, _inventoryFilter, shopProfile) { list, query, filter, shop ->
        val q = query.trim().lowercase(Locale.getDefault())
        list.filter { p ->
          val matchesQuery =
            q.isEmpty() ||
              p.name.lowercase(Locale.getDefault()).contains(q) ||
              p.genericName.lowercase(Locale.getDefault()).contains(q) ||
              p.brandName.lowercase(Locale.getDefault()).contains(q) ||
              p.boxLocation.lowercase(Locale.getDefault()).contains(q)
          if (!matchesQuery) return@filter false
          when (filter) {
            InventoryFilter.ALL -> true
            InventoryFilter.LOW_STOCK -> p.stock <= shop.lowStockThreshold
            InventoryFilter.EXPIRING -> isExpiringOrExpired(p.expiryDateIso)
          }
        }
      }
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private var autoSyncJob: Job? = null

  fun refreshNetworkState() {
    _isOnline.value = syncManager.isOnline()
  }

  fun updateSearchQuery(q: String) {
    _searchQuery.value = q
  }

  fun updateInventoryFilter(filter: InventoryFilter) {
    _inventoryFilter.value = filter
  }

  fun setSessionPassphrase(pass: String) {
    _sessionPassphrase.value = pass
  }

  fun clearDriveMessage() {
    _driveStatusMessage.value = null
  }

  // --- Shop Profile Operations ---

  fun updateShopProfile(profile: ShopProfile) {
    viewModelScope.launch {
      prefs.saveShopProfile(
        profile.copy(
          shopName = profile.shopName.trim().ifEmpty { "Smart Dokan POS" },
          shopSubtitle = profile.shopSubtitle.trim(),
          phone = profile.phone.trim(),
          address = profile.address.trim(),
          currencySymbol = profile.currencySymbol.trim().ifEmpty { "৳" },
          lowStockThreshold = profile.lowStockThreshold.coerceIn(1, 500),
        )
      )
      _toastEvents.emit(false to "দোকানের তথ্য আপডেট হয়েছে!")
      scheduleAutoSync()
    }
  }

  // --- Product & Sales Operations ---

  fun saveProduct(product: ProductEntity) {
    viewModelScope.launch {
      val isEdit = product.id != 0L
      repository.saveProduct(product)
      _toastEvents.emit(false to if (isEdit) "পণ্য আপডেট হয়েছে!" else "নতুন পণ্য যোগ হয়েছে!")
      scheduleAutoSync()
    }
  }

  fun deleteProduct(product: ProductEntity) {
    viewModelScope.launch {
      ImageStorageHelper.deleteImageFile(product.imagePath)
      repository.deleteProduct(product.id)
      _toastEvents.emit(false to "${product.name} মুছে ফেলা হয়েছে।")
      scheduleAutoSync()
    }
  }

  fun quickRestock(product: ProductEntity, qty: Int = 10) {
    viewModelScope.launch {
      repository.restockProduct(product, qty)
      _toastEvents.emit(false to "${product.name} — $qty পিস স্টক যোগ হয়েছে!")
      scheduleAutoSync()
    }
  }

  fun recordSale(productId: Long, quantity: Int) {
    viewModelScope.launch {
      try {
        val sale = repository.recordSale(productId, quantity)
        val cur = shopProfile.value.currencySymbol
        val profitStr = String.format(Locale.US, "%.1f", sale.netProfit)
        _toastEvents.emit(
          false to "বিক্রি সম্পন্ন: ${sale.productName} ($quantity পিস) • লাভ $cur$profitStr"
        )
        scheduleAutoSync()
      } catch (e: Exception) {
        _toastEvents.emit(true to (e.message ?: "বিক্রি রেকর্ড করা যায়নি।"))
      }
    }
  }

  fun updateSale(
    saleId: Long,
    newQty: Int,
    newBuyingPrice: Double,
    newSellingPrice: Double,
    newDateKey: String,
  ) {
    viewModelScope.launch {
      try {
        val updated =
          repository.updateSale(saleId, newQty, newBuyingPrice, newSellingPrice, newDateKey)
        _toastEvents.emit(false to "${updated.productName} বিক্রয় হিসাব আপডেট হয়েছে!")
        scheduleAutoSync()
      } catch (e: Exception) {
        _toastEvents.emit(true to (e.message ?: "বিক্রয় হিসাব আপডেট করা যায়নি।"))
      }
    }
  }

  fun deleteSaleAndRestoreStock(sale: SaleEntity) {
    viewModelScope.launch {
      try {
        repository.deleteSaleAndRestoreStock(sale.id)
        _toastEvents.emit(
          false to "${sale.productName} (${sale.quantity} পিস) বিক্রি বাতিল ও স্টক ফেরত হয়েছে।"
        )
        scheduleAutoSync()
      } catch (e: Exception) {
        _toastEvents.emit(true to (e.message ?: "বিক্রয় বাতিল করা যায়নি।"))
      }
    }
  }

  // --- Theme Studio Operations ---

  fun selectThemePreset(preset: ThemePreset) {
    viewModelScope.launch {
      val current = themeConfig.value
      prefs.saveThemeConfig(
        current.copy(
          presetId = preset.id,
          customAccentHex = preset.accentHex,
          customBgStartHex = preset.bgStartHex,
          customBgEndHex = preset.bgEndHex,
        )
      )
    }
  }

  fun updateCustomTheme(
    accentHex: Long? = null,
    bgStartHex: Long? = null,
    bgEndHex: Long? = null,
    meshStyle: MeshStyle? = null,
    blurIntensity: BlurIntensity? = null,
  ) {
    viewModelScope.launch {
      val current = themeConfig.value
      prefs.saveThemeConfig(
        current.copy(
          customAccentHex = accentHex ?: current.customAccentHex,
          customBgStartHex = bgStartHex ?: current.customBgStartHex,
          customBgEndHex = bgEndHex ?: current.customBgEndHex,
          meshStyle = meshStyle ?: current.meshStyle,
          blurIntensity = blurIntensity ?: current.blurIntensity,
        )
      )
    }
  }

  // --- Shopkeeper's Own Multi-Google Drive Link & Auto-Folder Operations ---

  fun addOrUpdateUserDriveLink(
    editingId: String?,
    label: String,
    scriptUrl: String,
    driveFolderUrlOrId: String,
    dataScope: DriveDataScope,
    autoSubfolders: Boolean,
  ) {
    viewModelScope.launch {
      val cleanScript = scriptUrl.trim().ifEmpty { defaultBridgeUrl.value.trim() }
      if (!DriveLinkParser.isValidAppsScriptEndpoint(cleanScript)) {
        _driveStatusMessage.value =
          true to "সঠিক Google Apps Script Web App লিংক (https://script.google.com/macros/...) দিন।"
        return@launch
      }
      if (!DriveLinkParser.isValidDriveFolderInput(driveFolderUrlOrId)) {
        _driveStatusMessage.value =
          true to "সঠিক Google Drive ফোল্ডার লিংক (https://drive.google.com/drive/folders/...) দিন অথবা খালি রাখুন।"
        return@launch
      }
      val folderId = DriveLinkParser.extractFolderId(driveFolderUrlOrId)
      prefs.saveDefaultBridgeUrl(cleanScript)

      val current = driveLinks.value
      if (editingId != null) {
        val updated =
          current.map { existing ->
            if (existing.id == editingId) {
              existing.copy(
                label = label.trim().ifEmpty { existing.label },
                scriptEndpointUrl = cleanScript,
                driveFolderUrl = driveFolderUrlOrId.trim(),
                folderId = folderId,
                dataScope = dataScope,
                autoSubfolders = autoSubfolders,
                status = DriveLinkStatus.READY,
                lastError = "",
              )
            } else {
              existing
            }
          }
        prefs.saveDriveLinks(updated)
        _driveStatusMessage.value = false to "ড্রাইভ ফোল্ডার লিংক আপডেট হয়েছে!"
      } else {
        val newLink =
          UserDriveLink(
            id = "drv_${System.currentTimeMillis()}",
            label = label.trim().ifEmpty { dataScope.shortLabelBn + " #${current.size + 1}" },
            scriptEndpointUrl = cleanScript,
            driveFolderUrl = driveFolderUrlOrId.trim(),
            folderId = folderId,
            dataScope = dataScope,
            autoSubfolders = autoSubfolders,
            enabled = true,
            status = DriveLinkStatus.READY,
          )
        prefs.saveDriveLinks(current + newLink)
        _driveStatusMessage.value = false to "নতুন গুগল ড্রাইভ ফোল্ডার লিংক সফলভাবে যুক্ত হয়েছে!"
      }
    }
  }

  fun removeDriveLink(id: String) {
    viewModelScope.launch {
      prefs.saveDriveLinks(driveLinks.value.filterNot { it.id == id })
    }
  }

  fun toggleDriveLinkEnabled(id: String, enabled: Boolean) {
    viewModelScope.launch {
      prefs.saveDriveLinks(
        driveLinks.value.map { if (it.id == id) it.copy(enabled = enabled) else it }
      )
    }
  }

  fun moveDrivePriority(id: String, moveUp: Boolean) {
    viewModelScope.launch {
      val list = driveLinks.value.toMutableList()
      val idx = list.indexOfFirst { it.id == id }
      val target = if (moveUp) idx - 1 else idx + 1
      if (idx in list.indices && target in list.indices) {
        val temp = list[idx]
        list[idx] = list[target]
        list[target] = temp
        prefs.saveDriveLinks(list)
      }
    }
  }

  fun setAutoSync(enabled: Boolean) {
    viewModelScope.launch { prefs.setAutoSync(enabled) }
  }

  fun testDriveLink(link: UserDriveLink) {
    viewModelScope.launch {
      _driveBusy.value = true
      _driveStatusMessage.value = null
      try {
        val msg = syncManager.testDriveLink(link)
        _driveStatusMessage.value = false to "${link.label}: $msg"
      } catch (e: Exception) {
        _driveStatusMessage.value = true to "${link.label}: ${e.message}"
      } finally {
        _driveBusy.value = false
      }
    }
  }

  fun syncAllDrivesNow(passphrase: String) {
    viewModelScope.launch {
      _sessionPassphrase.value = passphrase
      _driveBusy.value = true
      _syncState.value = SyncVisualState.SYNCING
      _driveStatusMessage.value = null
      try {
        val outcome = syncManager.syncWithFailover(passphrase)
        _syncState.value = SyncVisualState.SYNCED
        val syncedNames = outcome.syncedLabels.joinToString(", ")
        val failoverNote = if (outcome.failoverUsed) " (ফেইলওভারসহ)" else ""
        _driveStatusMessage.value =
          false to "সফলভাবে ড্রাইভ ফোল্ডারে সেভ হয়েছে: $syncedNames$failoverNote"
      } catch (e: Exception) {
        _syncState.value = SyncVisualState.ERROR
        _driveStatusMessage.value = true to (e.message ?: "সিঙ্ক ব্যর্থ হয়েছে।")
      } finally {
        _driveBusy.value = false
      }
    }
  }

  fun restoreFromDriveLink(link: UserDriveLink, passphrase: String) {
    viewModelScope.launch {
      _sessionPassphrase.value = passphrase
      _driveBusy.value = true
      _driveStatusMessage.value = null
      try {
        val outcome = syncManager.restoreFromDriveLink(link, passphrase)
        _driveStatusMessage.value =
          false to
            "${outcome.sourceLabel} থেকে রিস্টোর সম্পন্ন! (${outcome.productCount}টি পণ্য ও ${outcome.saleCount}টি বিক্রি)"
      } catch (e: Exception) {
        _driveStatusMessage.value = true to (e.message ?: "রিস্টোর ব্যর্থ হয়েছে।")
      } finally {
        _driveBusy.value = false
      }
    }
  }

  suspend fun buildEncryptedVaultJsonForSaf(passphrase: String): String {
    _sessionPassphrase.value = passphrase
    return syncManager.buildEncryptedEnvelopeJson(passphrase).second
  }

  fun restoreFromSafJson(json: String, passphrase: String) {
    viewModelScope.launch {
      _sessionPassphrase.value = passphrase
      _driveBusy.value = true
      _driveStatusMessage.value = null
      try {
        val outcome = syncManager.restoreFromEnvelopeJson(json, passphrase)
        _driveStatusMessage.value =
          false to
            "ফাইল থেকে রিস্টোর সম্পন্ন! (${outcome.productCount}টি পণ্য ও ${outcome.saleCount}টি বিক্রি)"
      } catch (e: Exception) {
        _driveStatusMessage.value = true to (e.message ?: "ফাইল রিস্টোর ব্যর্থ হয়েছে।")
      } finally {
        _driveBusy.value = false
      }
    }
  }

  private fun scheduleAutoSync() {
    refreshNetworkState()
    val pass = _sessionPassphrase.value
    if (!autoSyncEnabled.value || pass.length < 4 || !syncManager.isOnline()) return
    if (driveLinks.value.none { it.enabled }) return

    autoSyncJob?.cancel()
    autoSyncJob =
      viewModelScope.launch {
        delay(2500)
        _syncState.value = SyncVisualState.SYNCING
        try {
          syncManager.syncWithFailover(pass)
          _syncState.value = SyncVisualState.SYNCED
        } catch (_: Exception) {
          _syncState.value = SyncVisualState.ERROR
        }
      }
  }

  companion object {
    fun daysUntilExpiry(expiryIso: String): Int? {
      if (expiryIso.isBlank()) return null
      return runCatching {
          val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }
          val expDate = sdf.parse(expiryIso.trim()) ?: return null
          val todayStr = sdf.format(Date())
          val todayDate = sdf.parse(todayStr) ?: return null
          ((expDate.time - todayDate.time) / 86_400_000L).toInt()
        }
        .getOrNull()
    }

    fun isExpiringOrExpired(expiryIso: String): Boolean {
      val days = daysUntilExpiry(expiryIso) ?: return false
      return days <= 30
    }
  }
}
