package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.R
import com.example.data.local.ProductEntity
import com.example.data.local.SaleEntity
import com.example.data.prefs.ShopProfile
import com.example.ui.InventoryFilter
import com.example.ui.PosViewModel
import com.example.ui.components.ExpiryBadge
import com.example.ui.components.GlassCard
import com.example.ui.components.GlassPanelBox
import com.example.ui.components.GlassPillSearchBar
import com.example.ui.components.GlassTintedIconButton
import com.example.ui.components.LocationBadge
import com.example.ui.theme.DangerRose
import com.example.ui.theme.InfoBlue
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalGlassPalette
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.WarningAmber
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PosInventoryScreen(
  products: List<ProductEntity>,
  allProductCount: Int,
  sales: List<SaleEntity>,
  shopProfile: ShopProfile,
  searchQuery: String,
  activeFilter: InventoryFilter,
  isExpandedWidth: Boolean,
  onSearchChange: (String) -> Unit,
  onFilterChange: (InventoryFilter) -> Unit,
  onRecordSale: (productId: Long, qty: Int) -> Unit,
  onEditProduct: (ProductEntity) -> Unit,
  onDeleteProduct: (ProductEntity) -> Unit,
  onQuickRestock: (ProductEntity) -> Unit,
  onAddNewProduct: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val glass = LocalGlassPalette.current
  val cur = shopProfile.currencySymbol
  val todayKey = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
  val todaySales = remember(sales, todayKey) { sales.filter { it.dateKey == todayKey } }
  val todayRevenue = remember(todaySales) { todaySales.sumOf { it.totalRevenue } }
  val todayCost = remember(todaySales) { todaySales.sumOf { it.totalCost } }
  val todayProfit = remember(todaySales) { todaySales.sumOf { it.netProfit } }
  val todayQty = remember(todaySales) { todaySales.sumOf { it.quantity } }

  var previewImageProduct by remember { mutableStateOf<ProductEntity?>(null) }
  val columns = if (isExpandedWidth) 2 else 1

  LazyVerticalGrid(
    columns = GridCells.Fixed(columns),
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 92.dp),
    horizontalArrangement = Arrangement.spacedBy(12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    // Executive Financial Hero Summary + Search Bar
    item(span = { GridItemSpan(columns) }) {
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(
          shape = RoundedCornerShape(24.dp),
          color = Color.Transparent,
          border = BorderStroke(1.2.dp, glass.accent.copy(alpha = 0.55f)),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Box(
            modifier =
              Modifier.background(
                  Brush.linearGradient(
                    listOf(
                      glass.accent.copy(alpha = if (glass.isDark) 0.34f else 0.16f),
                      glass.glassCardBg,
                    )
                  )
                )
                .padding(16.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Column {
                Text(
                  text = "আজকের নিট লাভ",
                  style = MaterialTheme.typography.labelLarge,
                  color = glass.accent,
                  fontWeight = FontWeight.Bold,
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                  text = String.format(Locale.US, "%s %.2f", cur, todayProfit),
                  fontFamily = JetBrainsMonoFontFamily,
                  fontWeight = FontWeight.ExtraBold,
                  fontSize = 28.sp,
                  color = glass.textPrimary,
                )
                Text(
                  text = "মোট বিক্রি: $todayQty পিস • ${todaySales.size}টি লেনদেন",
                  style = MaterialTheme.typography.labelSmall,
                  color = glass.textSecondary,
                )
              }

              Surface(
                shape = RoundedCornerShape(18.dp),
                color = glass.accent,
                modifier = Modifier.size(52.dp),
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    Icons.Default.TrendingUp,
                    contentDescription = "আজকের নিট লাভ",
                    tint = Color.White,
                    modifier = Modifier.size(28.dp),
                  )
                }
              }
            }
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          MetricGlassTile(
            title = "আজকের মোট বিক্রি",
            amount = todayRevenue,
            currencySymbol = cur,
            subtitle = "ক্রেতা বিক্রয় মূল্য",
            iconTint = InfoBlue,
            icon = Icons.Default.ShoppingBag,
            modifier = Modifier.weight(1f),
          )
          MetricGlassTile(
            title = "আজকের আসল খরচ",
            amount = todayCost,
            currencySymbol = cur,
            subtitle = "পাইকারি / কেনা দাম",
            iconTint = WarningAmber,
            icon = Icons.Default.Wallet,
            modifier = Modifier.weight(1f),
          )
        }

        GlassCard(innerPadding = 12.dp) {
          GlassPillSearchBar(
            query = searchQuery,
            onQueryChange = onSearchChange,
            placeholder = "পণ্য খুঁজুন (নাম, গ্রুপ, কোম্পানি বা বক্স/তাক নং)...",
          )
          Spacer(modifier = Modifier.height(10.dp))
          FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            InventoryFilter.entries.forEach { filter ->
              val label =
                if (filter == InventoryFilter.ALL) "${filter.labelBn} ($allProductCount)"
                else filter.labelBn
              val selected = activeFilter == filter
              FilterChip(
                selected = selected,
                onClick = { onFilterChange(filter) },
                label = {
                  Text(
                    label,
                    maxLines = 1,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                  )
                },
                colors =
                  FilterChipDefaults.filterChipColors(
                    selectedContainerColor = glass.accent.copy(alpha = 0.18f),
                    selectedLabelColor = glass.accent,
                  ),
                shape = RoundedCornerShape(50),
                modifier = Modifier.testTag("filter_chip_${filter.name}"),
              )
            }
          }
        }
      }
    }

    if (products.isEmpty()) {
      item(span = { GridItemSpan(columns) }) {
        GlassCard(innerPadding = 18.dp) {
          Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            Box(
              modifier = Modifier.fillMaxWidth().height(175.dp).clip(RoundedCornerShape(18.dp))
            ) {
              Image(
                painter = painterResource(id = R.drawable.img_shop_hero_1795350654965),
                contentDescription = "স্মার্ট দোকান",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
              )
              Box(
                modifier =
                  Modifier.fillMaxSize()
                    .background(
                      Brush.verticalGradient(
                        listOf(Color.Transparent, Color.Black.copy(alpha = 0.45f))
                      )
                    )
              )
            }
            Text(
              text =
                if (allProductCount == 0) "আপনার ডিজিটাল দোকান শুরু করুন"
                else "এই সার্চে কোনো পণ্য পাওয়া যায়নি",
              style = MaterialTheme.typography.titleLarge,
              color = glass.textPrimary,
            )
            Text(
              text = "ছবি, কেনা দাম, বিক্রয় মূল্য ও বক্স লোকেশন যোগ করলেই প্রতিদিনের আসল লাভ স্বয়ংক্রিয়ভাবে হিসাব হবে।",
              style = MaterialTheme.typography.bodyMedium,
              color = glass.textSecondary,
            )
            Button(
              onClick = onAddNewProduct,
              shape = RoundedCornerShape(16.dp),
              colors =
                ButtonDefaults.buttonColors(
                  containerColor = glass.accent,
                  contentColor = Color.White,
                ),
              modifier = Modifier.fillMaxWidth().height(48.dp).testTag("empty_add_product_button"),
            ) {
              Icon(Icons.Default.Add, contentDescription = "পণ্য যোগ")
              Spacer(modifier = Modifier.width(6.dp))
              Text("প্রথম পণ্য যোগ করুন", fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    } else {
      items(products, key = { it.id }) { product ->
        ProductItemCard(
          product = product,
          currencySymbol = cur,
          lowStockThreshold = shopProfile.lowStockThreshold,
          onSold = { qty -> onRecordSale(product.id, qty) },
          onEdit = { onEditProduct(product) },
          onDelete = { onDeleteProduct(product) },
          onQuickRestock = { onQuickRestock(product) },
          onPreviewImage = { previewImageProduct = product },
        )
      }
    }
  }

  // Fullscreen photo preview dialog when tapping product thumbnail
  val previewTarget = previewImageProduct
  if (previewTarget != null && previewTarget.imagePath.isNotBlank()) {
    Dialog(onDismissRequest = { previewImageProduct = null }) {
      GlassCard(shape = RoundedCornerShape(24.dp), innerPadding = 12.dp) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = previewTarget.name,
            style = MaterialTheme.typography.titleMedium,
            color = glass.textPrimary,
            modifier = Modifier.weight(1f),
          )
          IconButton(onClick = { previewImageProduct = null }) {
            Icon(Icons.Default.Close, contentDescription = "বন্ধ করুন")
          }
        }
        Spacer(modifier = Modifier.height(8.dp))
        AsyncImage(
          model = File(previewTarget.imagePath),
          contentDescription = previewTarget.name,
          contentScale = ContentScale.Fit,
          modifier = Modifier.fillMaxWidth().height(280.dp).clip(RoundedCornerShape(16.dp)),
        )
      }
    }
  }
}

@Composable
private fun MetricGlassTile(
  title: String,
  amount: Double,
  currencySymbol: String,
  subtitle: String,
  iconTint: Color,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  modifier: Modifier = Modifier,
) {
  val glass = LocalGlassPalette.current
  GlassCard(modifier = modifier, shape = RoundedCornerShape(20.dp), innerPadding = 13.dp) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        color = glass.textSecondary,
        maxLines = 1,
      )
      Surface(
        shape = CircleShape,
        color = iconTint.copy(alpha = 0.14f),
        modifier = Modifier.size(28.dp),
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(icon, contentDescription = title, tint = iconTint, modifier = Modifier.size(15.dp))
        }
      }
    }
    Spacer(modifier = Modifier.height(6.dp))
    Text(
      text = String.format(Locale.US, "%s %.2f", currencySymbol, amount),
      fontFamily = JetBrainsMonoFontFamily,
      fontWeight = FontWeight.Bold,
      style = MaterialTheme.typography.titleLarge,
      color = glass.textPrimary,
      maxLines = 1,
    )
    Text(
      text = subtitle,
      style = MaterialTheme.typography.labelSmall,
      color = glass.textSecondary,
      maxLines = 1,
    )
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ProductItemCard(
  product: ProductEntity,
  currencySymbol: String,
  lowStockThreshold: Int,
  onSold: (Int) -> Unit,
  onEdit: () -> Unit,
  onDelete: () -> Unit,
  onQuickRestock: () -> Unit,
  onPreviewImage: () -> Unit,
) {
  val glass = LocalGlassPalette.current
  var qty by remember(product.id, product.stock) { mutableIntStateOf(1) }
  val isOutOfStock = product.stock <= 0
  val isLowStock = product.stock in 1..lowStockThreshold
  val expiryDays = remember(product.expiryDateIso) { PosViewModel.daysUntilExpiry(product.expiryDateIso) }
  val hasImage = remember(product.imagePath) { product.imagePath.isNotBlank() && File(product.imagePath).exists() }

  GlassCard(
    modifier = Modifier.fillMaxWidth().testTag("product_card_${product.id}"),
    shape = RoundedCornerShape(22.dp),
    innerPadding = 15.dp,
  ) {
    // Top Zone: Product Thumbnail + Title + Action Pills
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.Top,
    ) {
      Row(modifier = Modifier.weight(1f).padding(end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(
          shape = RoundedCornerShape(14.dp),
          color = glass.accent.copy(alpha = 0.12f),
          border = BorderStroke(1.dp, glass.glassBorder),
          modifier =
            Modifier.size(54.dp)
              .clip(RoundedCornerShape(14.dp))
              .clickable(enabled = hasImage) { onPreviewImage() },
        ) {
          if (hasImage) {
            AsyncImage(
              model = File(product.imagePath),
              contentDescription = product.name,
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize(),
            )
          } else {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                Icons.Default.Inventory2,
                contentDescription = product.name,
                tint = glass.accent,
                modifier = Modifier.size(24.dp),
              )
            }
          }
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = product.name,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = glass.textPrimary,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
          )
          val sub =
            listOf(product.genericName, product.brandName)
              .filter { it.isNotBlank() }
              .joinToString(" • ")
          if (sub.isNotBlank()) {
            Text(
              text = sub,
              style = MaterialTheme.typography.bodyMedium,
              color = glass.textSecondary,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
      }

      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        GlassTintedIconButton(
          icon = Icons.Default.AddShoppingCart,
          contentDescription = "দ্রুত স্টক +১০",
          tint = ProfitGreen,
          onClick = onQuickRestock,
          modifier = Modifier.testTag("restock_btn_${product.id}"),
        )
        GlassTintedIconButton(
          icon = Icons.Default.Edit,
          contentDescription = "এডিট করুন",
          tint = glass.accent,
          onClick = onEdit,
          modifier = Modifier.testTag("edit_btn_${product.id}"),
        )
        GlassTintedIconButton(
          icon = Icons.Default.Delete,
          contentDescription = "মুছে ফেলুন",
          tint = DangerRose,
          onClick = onDelete,
          modifier = Modifier.testTag("delete_btn_${product.id}"),
        )
      }
    }

    Spacer(modifier = Modifier.height(8.dp))
    FlowRow(
      horizontalArrangement = Arrangement.spacedBy(6.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      if (product.boxLocation.isNotBlank()) {
        LocationBadge(locationText = product.boxLocation)
      }
      if (expiryDays != null && expiryDays <= 30) {
        val text = if (expiryDays <= 0) "মেয়াদ শেষ!" else "মেয়াদ $expiryDays দিন বাকি"
        ExpiryBadge(expiryText = text, isExpired = expiryDays <= 0)
      }
      Surface(
        shape = RoundedCornerShape(10.dp),
        color = (if (product.unitProfit >= 0) ProfitGreen else DangerRose).copy(alpha = 0.14f),
      ) {
        Text(
          text =
            String.format(
              Locale.US,
              "লাভ %s%.1f (%.0f%%)",
              currencySymbol,
              product.unitProfit,
              product.marginPercent,
            ),
          fontFamily = JetBrainsMonoFontFamily,
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.Bold,
          color = if (product.unitProfit >= 0) ProfitGreen else DangerRose,
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
        )
      }
    }

    if (product.notes.isNotBlank()) {
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = "নোট: ${product.notes}",
        style = MaterialTheme.typography.bodyMedium,
        fontStyle = FontStyle.Italic,
        color = glass.textSecondary,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis,
      )
    }

    Spacer(modifier = Modifier.height(10.dp))

    GlassPanelBox(modifier = Modifier.fillMaxWidth()) {
      Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column {
          Text(
            text = "বিক্রয় মূল্য",
            style = MaterialTheme.typography.labelSmall,
            color = glass.textSecondary,
          )
          Text(
            text = String.format(Locale.US, "%s %.2f", currencySymbol, product.sellingPrice),
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 18.sp,
            color = glass.textPrimary,
          )
        }

        Column(horizontalAlignment = Alignment.End) {
          Text(
            text = "বর্তমান স্টক",
            style = MaterialTheme.typography.labelSmall,
            color = glass.textSecondary,
          )
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier =
                Modifier.size(8.dp)
                  .clip(CircleShape)
                  .background(
                    when {
                      isOutOfStock -> DangerRose
                      isLowStock -> WarningAmber
                      else -> ProfitGreen
                    }
                  )
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "${product.stock} পিস",
              fontFamily = JetBrainsMonoFontFamily,
              fontWeight = FontWeight.Bold,
              fontSize = 16.sp,
              color =
                when {
                  isOutOfStock -> DangerRose
                  isLowStock -> WarningAmber
                  else -> glass.textPrimary
                },
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      GlassPanelBox(shape = RoundedCornerShape(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(
            enabled = !isOutOfStock && qty > 1,
            onClick = { qty = (qty - 1).coerceAtLeast(1) },
            modifier = Modifier.minimumInteractiveComponentSize().testTag("qty_minus_${product.id}"),
          ) {
            Icon(Icons.Default.Remove, contentDescription = "কমান")
          }
          Text(
            text = "$qty",
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = glass.textPrimary,
            modifier = Modifier.padding(horizontal = 4.dp),
          )
          IconButton(
            enabled = !isOutOfStock && qty < product.stock,
            onClick = { qty = (qty + 1).coerceAtMost(product.stock) },
            modifier = Modifier.minimumInteractiveComponentSize().testTag("qty_plus_${product.id}"),
          ) {
            Icon(Icons.Default.Add, contentDescription = "বাড়ান")
          }
        }
      }

      Button(
        enabled = !isOutOfStock,
        onClick = {
          val validQty = qty.coerceIn(1, product.stock)
          onSold(validQty)
          qty = 1
        },
        shape = RoundedCornerShape(14.dp),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = glass.accent,
            contentColor = Color.White,
          ),
        modifier = Modifier.weight(1f).height(48.dp).testTag("sold_btn_${product.id}"),
      ) {
        Icon(
          Icons.Default.CheckCircle,
          contentDescription = "বিক্রি হয়েছে",
          modifier = Modifier.size(18.dp),
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text("বিক্রি হয়েছে", fontWeight = FontWeight.Bold, fontSize = 14.sp)
      }
    }
  }
}
