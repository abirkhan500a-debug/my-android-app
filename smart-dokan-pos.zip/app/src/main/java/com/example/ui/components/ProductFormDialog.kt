package com.example.ui.components

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.local.ProductEntity
import com.example.ui.theme.DangerRose
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalGlassPalette
import com.example.ui.theme.ProfitGreen
import com.example.util.ImageStorageHelper
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductFormDialog(
  editingProduct: ProductEntity?,
  onDismiss: () -> Unit,
  onSave: (ProductEntity) -> Unit,
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val glass = LocalGlassPalette.current

  var name by remember(editingProduct) { mutableStateOf(editingProduct?.name ?: "") }
  var buyingPriceText by remember(editingProduct) {
    mutableStateOf(
      editingProduct?.buyingPrice?.let { if (it == 0.0) "" else it.toString() } ?: ""
    )
  }
  var sellingPriceText by remember(editingProduct) {
    mutableStateOf(
      editingProduct?.sellingPrice?.let { if (it == 0.0) "" else it.toString() } ?: ""
    )
  }
  var stockText by remember(editingProduct) {
    mutableStateOf(editingProduct?.stock?.toString() ?: "")
  }
  var imagePath by remember(editingProduct) { mutableStateOf(editingProduct?.imagePath ?: "") }

  val hasAdvancedInitially =
    editingProduct != null &&
      (editingProduct.boxLocation.isNotBlank() ||
        editingProduct.brandName.isNotBlank() ||
        editingProduct.genericName.isNotBlank() ||
        editingProduct.expiryDateIso.isNotBlank() ||
        editingProduct.notes.isNotBlank())

  var advancedMode by remember(editingProduct) { mutableStateOf(hasAdvancedInitially) }
  var boxLocation by remember(editingProduct) {
    mutableStateOf(editingProduct?.boxLocation ?: "")
  }
  var brandName by remember(editingProduct) { mutableStateOf(editingProduct?.brandName ?: "") }
  var genericName by remember(editingProduct) {
    mutableStateOf(editingProduct?.genericName ?: "")
  }
  var expiryDateIso by remember(editingProduct) {
    mutableStateOf(editingProduct?.expiryDateIso ?: "")
  }
  var notes by remember(editingProduct) { mutableStateOf(editingProduct?.notes ?: "") }
  var showDatePicker by remember { mutableStateOf(false) }

  // Zero-permission Android Photo Picker (Play Policy Compliant)
  val photoPickerLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
      if (uri != null) {
        scope.launch {
          try {
            val savedPath = ImageStorageHelper.savePickedImage(context, uri)
            if (imagePath.isNotBlank() && imagePath != editingProduct?.imagePath) {
              ImageStorageHelper.deleteImageFile(imagePath)
            }
            imagePath = savedPath
          } catch (e: Exception) {
            Toast.makeText(context, e.message ?: "ছবি যোগ করা যায়নি", Toast.LENGTH_SHORT).show()
          }
        }
      }
    }

  val buyVal = buyingPriceText.toDoubleOrNull() ?: 0.0
  val sellVal = sellingPriceText.toDoubleOrNull() ?: 0.0
  val unitProfit = sellVal - buyVal
  val marginPct = if (sellVal > 0.0) (unitProfit / sellVal) * 100.0 else 0.0
  val isValid = name.trim().isNotEmpty() && sellingPriceText.toDoubleOrNull() != null

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false),
  ) {
    GlassCard(
      modifier = Modifier.fillMaxWidth(0.94f).padding(vertical = 16.dp),
      shape = RoundedCornerShape(26.dp),
      innerPadding = 18.dp,
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = if (editingProduct != null) "পণ্য আপডেট করুন" else "নতুন পণ্য যোগ করুন",
          style = MaterialTheme.typography.titleLarge,
          color = glass.textPrimary,
        )
        IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_product_dialog_button")) {
          Icon(Icons.Default.Close, contentDescription = "বন্ধ করুন", tint = glass.textPrimary)
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Column(
        modifier = Modifier.fillMaxWidth().weight(1f, fill = false).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        // Product Photo Upload Card
        GlassPanelBox(modifier = Modifier.fillMaxWidth()) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            Surface(
              shape = RoundedCornerShape(14.dp),
              color = glass.accent.copy(alpha = 0.12f),
              border = BorderStroke(1.dp, glass.glassBorder),
              modifier = Modifier.size(64.dp),
            ) {
              if (imagePath.isNotBlank() && File(imagePath).exists()) {
                AsyncImage(
                  model = File(imagePath),
                  contentDescription = "পণ্যের ছবি",
                  contentScale = ContentScale.Crop,
                  modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(14.dp)),
                )
              } else {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    Icons.Default.Image,
                    contentDescription = "ছবি নেই",
                    tint = glass.accent,
                    modifier = Modifier.size(28.dp),
                  )
                }
              }
            }

            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Text(
                text = "পণ্যের ছবি (ঐচ্ছিক)",
                style = MaterialTheme.typography.labelLarge,
                color = glass.textPrimary,
              )
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                  onClick = {
                    photoPickerLauncher.launch(
                      PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                  },
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.testTag("upload_product_image_button"),
                ) {
                  Icon(
                    Icons.Default.AddPhotoAlternate,
                    contentDescription = "ছবি আপলোড",
                    modifier = Modifier.size(16.dp),
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(if (imagePath.isNotBlank()) "পরিবর্তন" else "ছবি আপলোড")
                }

                if (imagePath.isNotBlank()) {
                  IconButton(
                    onClick = {
                      if (imagePath != editingProduct?.imagePath) {
                        ImageStorageHelper.deleteImageFile(imagePath)
                      }
                      imagePath = ""
                    },
                    modifier = Modifier.testTag("remove_product_image_button"),
                  ) {
                    Icon(Icons.Default.Delete, contentDescription = "ছবি মুছুন", tint = DangerRose)
                  }
                }
              }
            }
          }
        }

        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("পণ্যের নাম *") },
          placeholder = { Text("যেমন: Napa Extra 500mg বা মিনিকেট চাল ১ কেজি") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("product_name_input"),
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          OutlinedTextField(
            value = buyingPriceText,
            onValueChange = { buyingPriceText = it },
            label = { Text("কেনা দাম") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.weight(1f).testTag("buying_price_input"),
          )
          OutlinedTextField(
            value = sellingPriceText,
            onValueChange = { sellingPriceText = it },
            label = { Text("বিক্রয় মূল্য *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.weight(1f).testTag("selling_price_input"),
          )
          OutlinedTextField(
            value = stockText,
            onValueChange = { stockText = it.filter { ch -> ch.isDigit() } },
            label = { Text("স্টক") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.weight(0.8f).testTag("stock_input"),
          )
        }

        // Auto-Profit Calculator Banner
        GlassPanelBox(modifier = Modifier.fillMaxWidth()) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                Icons.Default.Calculate,
                contentDescription = "লাভ ক্যালকুলেটর",
                tint = glass.accent,
                modifier = Modifier.size(18.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "প্রতি পিস লাভ:",
                style = MaterialTheme.typography.labelLarge,
                color = glass.textPrimary,
              )
            }
            Text(
              text = String.format(Locale.US, "৳ %.2f (%.1f%%)", unitProfit, marginPct),
              fontFamily = JetBrainsMonoFontFamily,
              fontWeight = FontWeight.Bold,
              color = if (unitProfit >= 0.0) ProfitGreen else DangerRose,
            )
          }
        }

        // Dual-mode Toggle Switch
        GlassPanelBox(modifier = Modifier.fillMaxWidth()) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Row(
              modifier = Modifier.weight(1f),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                Icons.Default.Layers,
                contentDescription = "বিস্তারিত মোড",
                tint = glass.accent,
                modifier = Modifier.size(18.dp),
              )
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text(
                  text = "বিস্তারিত তথ্য ও বক্স লোকেশন যোগ করুন",
                  style = MaterialTheme.typography.labelLarge,
                  color = glass.textPrimary,
                )
                Text(
                  text = "ফার্মেসি, কসমেটিক্স ও হার্ডওয়্যারের জন্য",
                  style = MaterialTheme.typography.labelSmall,
                  color = glass.textSecondary,
                )
              }
            }
            Switch(
              checked = advancedMode,
              onCheckedChange = { advancedMode = it },
              modifier = Modifier.testTag("pharmacy_mode_switch"),
            )
          }
        }

        AnimatedVisibility(visible = advancedMode) {
          Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(
              value = boxLocation,
              onValueChange = { boxLocation = it },
              label = { Text("বক্স ও তাকের লোকেশন") },
              placeholder = { Text("যেমন: Rack-3 | Shelf-2 | Box-B4") },
              leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = "লোকেশন") },
              singleLine = true,
              modifier = Modifier.fillMaxWidth().testTag("box_location_input"),
            )

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              OutlinedTextField(
                value = brandName,
                onValueChange = { brandName = it },
                label = { Text("কোম্পানি / ব্র্যান্ড") },
                placeholder = { Text("Square, Beximco") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("brand_name_input"),
              )
              OutlinedTextField(
                value = genericName,
                onValueChange = { genericName = it },
                label = { Text("গ্রুপ / ক্যাটাগরি") },
                placeholder = { Text("Paracetamol") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("generic_name_input"),
              )
            }

            OutlinedTextField(
              value = expiryDateIso,
              onValueChange = { expiryDateIso = it },
              label = { Text("মেয়াদোত্তীর্ণের তারিখ (YYYY-MM-DD)") },
              placeholder = { Text("2027-06-30") },
              trailingIcon = {
                IconButton(
                  onClick = { showDatePicker = true },
                  modifier = Modifier.testTag("pick_expiry_date_button"),
                ) {
                  Icon(Icons.Default.CalendarMonth, contentDescription = "তারিখ বাছাই")
                }
              },
              singleLine = true,
              modifier = Modifier.fillMaxWidth().testTag("expiry_date_input"),
            )

            OutlinedTextField(
              value = notes,
              onValueChange = { notes = it },
              label = { Text("বিশেষ নোট / ব্যবহারবিধি") },
              placeholder = { Text("খাওয়ার পর ১টি করে দিনে ২ বার / ৬ মাসের ওয়ারেন্টি") },
              maxLines = 3,
              modifier = Modifier.fillMaxWidth().testTag("product_notes_input"),
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        OutlinedButton(
          onClick = onDismiss,
          modifier = Modifier.testTag("cancel_product_button"),
        ) { Text("বাতিল") }
        Spacer(modifier = Modifier.width(10.dp))
        Button(
          enabled = isValid,
          onClick = {
            if (
              editingProduct != null &&
                editingProduct.imagePath.isNotBlank() &&
                editingProduct.imagePath != imagePath
            ) {
              ImageStorageHelper.deleteImageFile(editingProduct.imagePath)
            }
            val saved =
              ProductEntity(
                id = editingProduct?.id ?: 0L,
                name = name.trim(),
                buyingPrice = buyVal,
                sellingPrice = sellVal,
                stock = (stockText.toIntOrNull() ?: 0).coerceAtLeast(0),
                boxLocation = if (advancedMode) boxLocation.trim() else "",
                brandName = if (advancedMode) brandName.trim() else "",
                genericName = if (advancedMode) genericName.trim() else "",
                expiryDateIso = if (advancedMode) expiryDateIso.trim() else "",
                notes = if (advancedMode) notes.trim() else "",
                imagePath = imagePath,
                createdAt = editingProduct?.createdAt ?: System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis(),
              )
            onSave(saved)
            onDismiss()
          },
          colors = ButtonDefaults.buttonColors(containerColor = glass.accent, contentColor = Color.White),
          modifier = Modifier.testTag("save_product_button"),
        ) {
          Text(if (editingProduct != null) "আপডেট সেভ করুন" else "পণ্য সেভ করুন")
        }
      }
    }
  }

  if (showDatePicker) {
    val datePickerState = rememberDatePickerState()
    DatePickerDialog(
      onDismissRequest = { showDatePicker = false },
      confirmButton = {
        TextButton(
          onClick = {
            datePickerState.selectedDateMillis?.let { millis ->
              val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
              }
              expiryDateIso = sdf.format(Date(millis))
            }
            showDatePicker = false
          }
        ) { Text("ঠিক আছে") }
      },
      dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("বাতিল") } },
    ) {
      DatePicker(state = datePickerState)
    }
  }
}
