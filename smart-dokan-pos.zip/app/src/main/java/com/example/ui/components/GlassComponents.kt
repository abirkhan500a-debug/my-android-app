package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.prefs.MeshStyle
import com.example.data.prefs.ThemeConfig
import com.example.ui.theme.DangerRose
import com.example.ui.theme.HindSiliguriFontFamily
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalGlassPalette
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.WarningAmber

@Composable
fun MeshGlassBackground(
  themeConfig: ThemeConfig,
  modifier: Modifier = Modifier,
  content: @Composable BoxScope.() -> Unit,
) {
  val glass = LocalGlassPalette.current
  Box(
    modifier =
      modifier.fillMaxSize().drawBehind {
        when (themeConfig.meshStyle) {
          MeshStyle.AURORA -> {
            drawRect(
              brush =
                Brush.linearGradient(
                  colors = listOf(glass.bgStart, glass.bgMid, glass.bgEnd),
                  start = Offset.Zero,
                  end = Offset(size.width, size.height),
                )
            )
            drawCircle(
              brush =
                Brush.radialGradient(
                  colors = listOf(glass.accent.copy(alpha = 0.28f), Color.Transparent),
                  center = Offset(size.width * 0.88f, size.height * 0.10f),
                  radius = size.maxDimension * 0.55f,
                ),
              center = Offset(size.width * 0.88f, size.height * 0.10f),
              radius = size.maxDimension * 0.55f,
            )
            drawCircle(
              brush =
                Brush.radialGradient(
                  colors = listOf(glass.secondaryAccent.copy(alpha = 0.24f), Color.Transparent),
                  center = Offset(size.width * 0.12f, size.height * 0.78f),
                  radius = size.maxDimension * 0.52f,
                ),
              center = Offset(size.width * 0.12f, size.height * 0.78f),
              radius = size.maxDimension * 0.52f,
            )
            drawCircle(
              brush =
                Brush.radialGradient(
                  colors = listOf(glass.accent.copy(alpha = 0.12f), Color.Transparent),
                  center = Offset(size.width * 0.5f, size.height * 0.45f),
                  radius = size.maxDimension * 0.45f,
                ),
              center = Offset(size.width * 0.5f, size.height * 0.45f),
              radius = size.maxDimension * 0.45f,
            )
          }
          MeshStyle.DIAGONAL -> {
            drawRect(
              brush =
                Brush.linearGradient(
                  colors = listOf(glass.bgStart, glass.bgMid, glass.bgEnd),
                  start = Offset.Zero,
                  end = Offset(size.width, size.height),
                )
            )
          }
          MeshStyle.RADIAL -> {
            drawRect(color = glass.bgMid)
            drawCircle(
              brush =
                Brush.radialGradient(
                  colors =
                    listOf(
                      glass.accent.copy(alpha = 0.34f),
                      glass.bgStart.copy(alpha = 0.32f),
                      Color.Transparent,
                    ),
                  center = Offset(size.width * 0.22f, size.height * 0.14f),
                  radius = size.maxDimension * 0.85f,
                ),
              center = Offset(size.width * 0.22f, size.height * 0.14f),
              radius = size.maxDimension * 0.85f,
            )
          }
        }
      },
    content = content,
  )
}

@Composable
fun GlassCard(
  modifier: Modifier = Modifier,
  shape: Shape = RoundedCornerShape(24.dp),
  accentHighlight: Color? = null,
  innerPadding: Dp = 16.dp,
  content: @Composable ColumnScope.() -> Unit,
) {
  val glass = LocalGlassPalette.current
  val borderBrush =
    if (accentHighlight != null) {
      Brush.verticalGradient(
        listOf(accentHighlight.copy(alpha = 0.85f), accentHighlight.copy(alpha = 0.35f))
      )
    } else {
      Brush.verticalGradient(
        listOf(glass.glassBorder, glass.glassBorder.copy(alpha = 0.28f))
      )
    }

  Surface(
    modifier = modifier,
    shape = shape,
    color = glass.glassCardBg,
    border = BorderStroke(if (accentHighlight != null) 1.5.dp else 1.dp, borderBrush),
    shadowElevation = 0.dp,
    tonalElevation = 0.dp,
  ) {
    Column(modifier = Modifier.padding(innerPadding), content = content)
  }
}

@Composable
fun GlassPanelBox(
  modifier: Modifier = Modifier,
  shape: Shape = RoundedCornerShape(16.dp),
  content: @Composable BoxScope.() -> Unit,
) {
  val glass = LocalGlassPalette.current
  Surface(
    modifier = modifier,
    shape = shape,
    color = glass.glassInnerBg,
    border =
      BorderStroke(
        1.dp,
        Brush.verticalGradient(
          listOf(glass.glassBorder.copy(alpha = 0.7f), glass.glassBorder.copy(alpha = 0.25f))
        ),
      ),
    shadowElevation = 0.dp,
  ) {
    Box(content = content)
  }
}

@Composable
fun GlassPillSearchBar(
  query: String,
  onQueryChange: (String) -> Unit,
  placeholder: String,
  modifier: Modifier = Modifier,
) {
  val glass = LocalGlassPalette.current
  Surface(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(50),
    color = glass.glassInnerBg,
    border = BorderStroke(1.dp, glass.glassBorder),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Icon(
        imageVector = Icons.Default.Search,
        contentDescription = "অনুসন্ধান",
        tint = glass.accent,
        modifier = Modifier.size(20.dp),
      )
      Spacer(modifier = Modifier.width(10.dp))
      Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
        if (query.isEmpty()) {
          Text(
            text = placeholder,
            style = MaterialTheme.typography.bodyMedium,
            color = glass.textSecondary.copy(alpha = 0.75f),
            maxLines = 1,
          )
        }
        BasicTextField(
          value = query,
          onValueChange = onQueryChange,
          singleLine = true,
          textStyle =
            TextStyle(
              fontFamily = HindSiliguriFontFamily,
              fontSize = 14.sp,
              color = glass.textPrimary,
              fontWeight = FontWeight.Medium,
            ),
          cursorBrush = SolidColor(glass.accent),
          modifier = Modifier.fillMaxWidth().testTag("master_search_input"),
        )
      }
      if (query.isNotEmpty()) {
        Spacer(modifier = Modifier.width(6.dp))
        Box(
          modifier =
            Modifier.size(26.dp)
              .clip(CircleShape)
              .background(glass.textSecondary.copy(alpha = 0.14f))
              .clickable { onQueryChange("") }
              .testTag("clear_search_button"),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            Icons.Default.Close,
            contentDescription = "মুছুন",
            tint = glass.textPrimary,
            modifier = Modifier.size(14.dp),
          )
        }
      }
    }
  }
}

@Composable
fun GlassTintedIconButton(
  icon: ImageVector,
  contentDescription: String,
  tint: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier.size(38.dp),
    shape = CircleShape,
    color = tint.copy(alpha = 0.13f),
    border = BorderStroke(1.dp, tint.copy(alpha = 0.22f)),
    onClick = onClick,
  ) {
    Box(contentAlignment = Alignment.Center) {
      Icon(
        imageVector = icon,
        contentDescription = contentDescription,
        tint = tint,
        modifier = Modifier.size(18.dp),
      )
    }
  }
}

@Composable
fun LocationBadge(locationText: String, modifier: Modifier = Modifier) {
  if (locationText.isBlank()) return
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(10.dp),
    color = WarningAmber.copy(alpha = 0.16f),
    border = BorderStroke(1.dp, WarningAmber.copy(alpha = 0.45f)),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Icon(
        imageVector = Icons.Default.LocationOn,
        contentDescription = "লোকেশন",
        tint = Color(0xFFD97706),
        modifier = Modifier.size(13.dp),
      )
      Spacer(modifier = Modifier.width(4.dp))
      Text(
        text = locationText,
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        color = if (LocalGlassPalette.current.isDark) Color(0xFFFDE68A) else Color(0xFF92400E),
        fontSize = 11.sp,
      )
    }
  }
}

@Composable
fun ExpiryBadge(expiryText: String, isExpired: Boolean, modifier: Modifier = Modifier) {
  val bgColor = if (isExpired) DangerRose else WarningAmber
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(10.dp),
    color = bgColor,
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Icon(
        imageVector = Icons.Default.Warning,
        contentDescription = "মেয়াদ সতর্কতা",
        tint = Color.White,
        modifier = Modifier.size(12.dp),
      )
      Spacer(modifier = Modifier.width(4.dp))
      Text(
        text = expiryText,
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        color = Color.White,
        fontSize = 11.sp,
      )
    }
  }
}

data class DailyChartPoint(
  val dayLabel: String,
  val revenue: Double,
  val profit: Double,
)

@Composable
fun WeeklyProfitBarChart(
  points: List<DailyChartPoint>,
  modifier: Modifier = Modifier,
) {
  val glass = LocalGlassPalette.current
  val maxVal = points.maxOfOrNull { maxOf(it.revenue, it.profit) }?.coerceAtLeast(1.0) ?: 1.0

  Column(modifier = modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = "গত ৭ দিনের বিক্রি ও লাভের গ্রাফ",
        style = MaterialTheme.typography.titleMedium,
        color = glass.textPrimary,
      )
      Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        LegendDot(color = glass.secondaryAccent.copy(alpha = 0.55f), label = "বিক্রি")
        LegendDot(color = glass.accent, label = "নিট লাভ")
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    Canvas(modifier = Modifier.fillMaxWidth().height(120.dp)) {
      val count = points.size.coerceAtLeast(1)
      val groupWidth = size.width / count
      val barWidth = (groupWidth * 0.28f).coerceAtMost(24.dp.toPx())
      val gap = 4.dp.toPx()

      // Subtle baseline
      drawLine(
        color = glass.glassBorder,
        start = Offset(0f, size.height),
        end = Offset(size.width, size.height),
        strokeWidth = 1.dp.toPx(),
      )

      points.forEachIndexed { idx, pt ->
        val centerX = groupWidth * idx + groupWidth / 2f
        val revHeight = ((pt.revenue / maxVal) * (size.height - 8.dp.toPx())).toFloat().coerceAtLeast(4f)
        val profHeight =
          ((pt.profit.coerceAtLeast(0.0) / maxVal) * (size.height - 8.dp.toPx())).toFloat().coerceAtLeast(4f)

        drawRoundRect(
          color = glass.secondaryAccent.copy(alpha = 0.45f),
          topLeft = Offset(centerX - barWidth - gap / 2f, size.height - revHeight),
          size = Size(barWidth, revHeight),
          cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx()),
        )

        drawRoundRect(
          brush = Brush.verticalGradient(listOf(glass.accent, ProfitGreen)),
          topLeft = Offset(centerX + gap / 2f, size.height - profHeight),
          size = Size(barWidth, profHeight),
          cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx()),
        )
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    Row(modifier = Modifier.fillMaxWidth()) {
      points.forEach { pt ->
        Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
          Text(
            text = pt.dayLabel,
            fontFamily = JetBrainsMonoFontFamily,
            style = MaterialTheme.typography.labelSmall,
            color = glass.textSecondary,
          )
        }
      }
    }
  }
}

@Composable
private fun LegendDot(color: Color, label: String) {
  val glass = LocalGlassPalette.current
  Row(verticalAlignment = Alignment.CenterVertically) {
    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(color))
    Spacer(modifier = Modifier.width(4.dp))
    Text(text = label, style = MaterialTheme.typography.labelSmall, color = glass.textSecondary)
  }
}
