package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.ProductEntity
import com.example.data.local.SaleEntity
import com.example.ui.components.DriveBackupSheet
import com.example.ui.components.GlassCard
import com.example.ui.components.GlassTintedIconButton
import com.example.ui.components.MeshGlassBackground
import com.example.ui.components.ProductFormDialog
import com.example.ui.components.SaleEditDialog
import com.example.ui.components.ShopProfileDialog
import com.example.ui.components.ThemeStudioSheet
import com.example.ui.screens.FinancialDashboardScreen
import com.example.ui.screens.PosInventoryScreen
import com.example.ui.screens.ShortListScreen
import com.example.ui.theme.DangerRose
import com.example.ui.theme.LocalGlassPalette
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.SmartDokanTheme
import com.example.ui.theme.WarningAmber

private enum class MainTab(val labelBn: String) {
  POS("বিক্রি ও পণ্য"),
  DASHBOARD("ড্যাশবোর্ড"),
  SHORTLIST("শর্ট লিস্ট"),
}

@Composable
fun SmartDokanApp(viewModel: PosViewModel = viewModel()) {
  val themeConfig by viewModel.themeConfig.collectAsStateWithLifecycle()
  val shopProfile by viewModel.shopProfile.collectAsStateWithLifecycle()
  val allProducts by viewModel.products.collectAsStateWithLifecycle()
  val filteredProducts by viewModel.filteredProducts.collectAsStateWithLifecycle()
  val sales by viewModel.sales.collectAsStateWithLifecycle()
  val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
  val activeFilter by viewModel.inventoryFilter.collectAsStateWithLifecycle()
  val driveLinks by viewModel.driveLinks.collectAsStateWithLifecycle()
  val defaultBridgeUrl by viewModel.defaultBridgeUrl.collectAsStateWithLifecycle()
  val autoSync by viewModel.autoSyncEnabled.collectAsStateWithLifecycle()
  val lastSyncedAt by viewModel.lastSyncedAt.collectAsStateWithLifecycle()
  val activeDriveLabel by viewModel.activeDriveLabel.collectAsStateWithLifecycle()
  val sessionPassphrase by viewModel.sessionPassphrase.collectAsStateWithLifecycle()
  val driveMessage by viewModel.driveStatusMessage.collectAsStateWithLifecycle()
  val driveBusy by viewModel.driveBusy.collectAsStateWithLifecycle()
  val syncState by viewModel.syncState.collectAsStateWithLifecycle()
  val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()

  var activeTab by remember { mutableStateOf(MainTab.POS) }
  var showProductDialog by remember { mutableStateOf(false) }
  var editingProduct by remember { mutableStateOf<ProductEntity?>(null) }
  var pendingDeleteProduct by remember { mutableStateOf<ProductEntity?>(null) }
  var editingSale by remember { mutableStateOf<SaleEntity?>(null) }
  var pendingDeleteSale by remember { mutableStateOf<SaleEntity?>(null) }
  var showShopProfileDialog by remember { mutableStateOf(false) }
  var showThemeStudio by remember { mutableStateOf(false) }
  var showDriveSheet by remember { mutableStateOf(false) }

  val snackbarHostState = remember { SnackbarHostState() }

  LaunchedEffect(Unit) {
    viewModel.refreshNetworkState()
    viewModel.toastEvents.collect { (_, msg) ->
      snackbarHostState.showSnackbar(msg)
    }
  }

  BackHandler(enabled = activeTab != MainTab.POS) {
    activeTab = MainTab.POS
  }

  val lowStockCount =
    remember(allProducts, shopProfile.lowStockThreshold) {
      allProducts.count { it.stock <= shopProfile.lowStockThreshold }
    }
  val hasConfiguredDrive = remember(driveLinks) { driveLinks.any { it.enabled } }

  SmartDokanTheme(themeConfig = themeConfig) {
    val glass = LocalGlassPalette.current
    MeshGlassBackground(themeConfig = themeConfig) {
      BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth >= 600.dp

        Scaffold(
          containerColor = Color.Transparent,
          contentWindowInsets = WindowInsets.safeDrawing,
          snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
          topBar = {
            GlassTopBar(
              shopName = shopProfile.shopName,
              isOnline = isOnline,
              hasConfiguredDrive = hasConfiguredDrive,
              driveCount = driveLinks.count { it.enabled },
              syncState = syncState,
              onEditShop = { showShopProfileDialog = true },
              onOpenDrive = {
                viewModel.refreshNetworkState()
                viewModel.clearDriveMessage()
                showDriveSheet = true
              },
              onOpenTheme = { showThemeStudio = true },
            )
          },
          bottomBar = {
            if (!isWideScreen) {
              Column {
                HorizontalDivider(color = glass.glassBorder.copy(alpha = 0.55f), thickness = 1.dp)
                NavigationBar(
                  containerColor = glass.glassBarBg,
                  tonalElevation = 0.dp,
                ) {
                  MainTab.entries.forEach { tab ->
                    val icon =
                      when (tab) {
                        MainTab.POS -> Icons.Default.Inventory2
                        MainTab.DASHBOARD -> Icons.Default.Dashboard
                        MainTab.SHORTLIST -> Icons.Default.Warning
                      }
                    NavigationBarItem(
                      selected = activeTab == tab,
                      onClick = { activeTab = tab },
                      colors =
                        NavigationBarItemDefaults.colors(
                          selectedIconColor = glass.accent,
                          selectedTextColor = glass.accent,
                          indicatorColor = glass.accent.copy(alpha = 0.16f),
                          unselectedIconColor = glass.textSecondary,
                          unselectedTextColor = glass.textSecondary,
                        ),
                      icon = {
                        if (tab == MainTab.SHORTLIST && lowStockCount > 0) {
                          BadgedBox(badge = { Badge { Text("$lowStockCount") } }) {
                            Icon(icon, contentDescription = tab.labelBn)
                          }
                        } else {
                          Icon(icon, contentDescription = tab.labelBn)
                        }
                      },
                      label = {
                        Text(
                          tab.labelBn,
                          maxLines = 1,
                          fontWeight = if (activeTab == tab) FontWeight.Bold else FontWeight.Medium,
                        )
                      },
                      modifier = Modifier.testTag("nav_tab_${tab.name}"),
                    )
                  }
                }
              }
            }
          },
          floatingActionButton = {
            if (activeTab == MainTab.POS) {
              FloatingActionButton(
                onClick = {
                  editingProduct = null
                  showProductDialog = true
                },
                shape = RoundedCornerShape(18.dp),
                containerColor = glass.accent,
                contentColor = Color.White,
                modifier = Modifier.testTag("fab_add_product"),
              ) {
                Icon(Icons.Default.Add, contentDescription = "নতুন পণ্য যোগ করুন")
              }
            }
          },
        ) { innerPadding ->
          Row(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            if (isWideScreen) {
              NavigationRail(
                containerColor = glass.glassBarBg,
                modifier = Modifier.fillMaxHeight(),
              ) {
                Spacer(modifier = Modifier.weight(0.1f))
                MainTab.entries.forEach { tab ->
                  val icon =
                    when (tab) {
                      MainTab.POS -> Icons.Default.Inventory2
                      MainTab.DASHBOARD -> Icons.Default.Dashboard
                      MainTab.SHORTLIST -> Icons.Default.Warning
                    }
                  NavigationRailItem(
                    selected = activeTab == tab,
                    onClick = { activeTab = tab },
                    icon = {
                      if (tab == MainTab.SHORTLIST && lowStockCount > 0) {
                        BadgedBox(badge = { Badge { Text("$lowStockCount") } }) {
                          Icon(icon, contentDescription = tab.labelBn)
                        }
                      } else {
                        Icon(icon, contentDescription = tab.labelBn)
                      }
                    },
                    label = { Text(tab.labelBn) },
                    modifier = Modifier.testTag("rail_tab_${tab.name}"),
                  )
                }
                Spacer(modifier = Modifier.weight(1f))
              }
            }

            Box(
              modifier = Modifier.weight(1f).fillMaxHeight(),
              contentAlignment = Alignment.TopCenter,
            ) {
              val contentMod = Modifier.fillMaxSize().widthIn(max = 1040.dp)
              when (activeTab) {
                MainTab.POS -> {
                  PosInventoryScreen(
                    products = filteredProducts,
                    allProductCount = allProducts.size,
                    sales = sales,
                    shopProfile = shopProfile,
                    searchQuery = searchQuery,
                    activeFilter = activeFilter,
                    isExpandedWidth = isWideScreen,
                    onSearchChange = viewModel::updateSearchQuery,
                    onFilterChange = viewModel::updateInventoryFilter,
                    onRecordSale = viewModel::recordSale,
                    onEditProduct = { prod ->
                      editingProduct = prod
                      showProductDialog = true
                    },
                    onDeleteProduct = { prod -> pendingDeleteProduct = prod },
                    onQuickRestock = { prod -> viewModel.quickRestock(prod, 10) },
                    onAddNewProduct = {
                      editingProduct = null
                      showProductDialog = true
                    },
                    modifier = contentMod,
                  )
                }
                MainTab.DASHBOARD -> {
                  FinancialDashboardScreen(
                    sales = sales,
                    products = allProducts,
                    shopProfile = shopProfile,
                    onEditShopProfile = { showShopProfileDialog = true },
                    onEditSale = { sale -> editingSale = sale },
                    onDeleteSale = { sale -> pendingDeleteSale = sale },
                    onEditProductById = { prodId ->
                      allProducts.firstOrNull { it.id == prodId }?.let { prod ->
                        editingProduct = prod
                        showProductDialog = true
                      }
                    },
                    modifier = contentMod,
                  )
                }
                MainTab.SHORTLIST -> {
                  ShortListScreen(
                    products = allProducts,
                    shopProfile = shopProfile,
                    onQuickRestock = { prod -> viewModel.quickRestock(prod, 10) },
                    onEditProduct = { prod ->
                      editingProduct = prod
                      showProductDialog = true
                    },
                    modifier = contentMod,
                  )
                }
              }
            }
          }
        }
      }

      if (showProductDialog) {
        ProductFormDialog(
          editingProduct = editingProduct,
          onDismiss = { showProductDialog = false },
          onSave = viewModel::saveProduct,
        )
      }

      if (showShopProfileDialog) {
        ShopProfileDialog(
          currentProfile = shopProfile,
          onDismiss = { showShopProfileDialog = false },
          onSave = viewModel::updateShopProfile,
        )
      }

      val targetEditSale = editingSale
      if (targetEditSale != null) {
        SaleEditDialog(
          sale = targetEditSale,
          currencySymbol = shopProfile.currencySymbol,
          onDismiss = { editingSale = null },
          onSave = viewModel::updateSale,
        )
      }

      if (showThemeStudio) {
        ThemeStudioSheet(
          themeConfig = themeConfig,
          onSelectPreset = viewModel::selectThemePreset,
          onUpdateCustom = viewModel::updateCustomTheme,
          onDismiss = { showThemeStudio = false },
        )
      }

      if (showDriveSheet) {
        DriveBackupSheet(
          driveLinks = driveLinks,
          defaultBridgeUrl = defaultBridgeUrl,
          autoSyncEnabled = autoSync,
          sessionPassphrase = sessionPassphrase,
          lastSyncedAt = lastSyncedAt,
          activeDriveLabel = activeDriveLabel,
          isBusy = driveBusy,
          statusMessage = driveMessage,
          onPassphraseChange = viewModel::setSessionPassphrase,
          onSaveDriveLink = viewModel::addOrUpdateUserDriveLink,
          onRemoveDriveLink = viewModel::removeDriveLink,
          onToggleDriveLink = viewModel::toggleDriveLinkEnabled,
          onMovePriority = viewModel::moveDrivePriority,
          onSetAutoSync = viewModel::setAutoSync,
          onTestLink = viewModel::testDriveLink,
          onSyncAll = viewModel::syncAllDrivesNow,
          onRestoreFromLink = viewModel::restoreFromDriveLink,
          onBuildVaultJson = viewModel::buildEncryptedVaultJsonForSaf,
          onRestoreFromSafJson = viewModel::restoreFromSafJson,
          onDismiss = { showDriveSheet = false },
        )
      }

      if (pendingDeleteProduct != null) {
        val target = pendingDeleteProduct!!
        AlertDialog(
          onDismissRequest = { pendingDeleteProduct = null },
          title = { Text("পণ্য মুছে ফেলবেন?") },
          text = { Text("আপনি কি নিশ্চিতভাবে \"${target.name}\" মুছে ফেলতে চান?") },
          confirmButton = {
            TextButton(
              onClick = {
                viewModel.deleteProduct(target)
                pendingDeleteProduct = null
              },
              modifier = Modifier.testTag("confirm_delete_button"),
            ) {
              Text("মুছে ফেলুন", color = DangerRose, fontWeight = FontWeight.Bold)
            }
          },
          dismissButton = {
            TextButton(onClick = { pendingDeleteProduct = null }) { Text("বাতিল") }
          },
        )
      }

      if (pendingDeleteSale != null) {
        val saleTarget = pendingDeleteSale!!
        AlertDialog(
          onDismissRequest = { pendingDeleteSale = null },
          title = { Text("বিক্রি বাতিল করবেন?") },
          text = {
            Text(
              "\"${saleTarget.productName}\" (${saleTarget.quantity} পিস) বিক্রি বাতিল করলে এর স্টক আবার পণ্যে ফেরত যোগ হবে।"
            )
          },
          confirmButton = {
            TextButton(
              onClick = {
                viewModel.deleteSaleAndRestoreStock(saleTarget)
                pendingDeleteSale = null
              },
              modifier = Modifier.testTag("confirm_delete_sale_button"),
            ) {
              Text("বাতিল ও স্টক ফেরত", color = DangerRose, fontWeight = FontWeight.Bold)
            }
          },
          dismissButton = {
            TextButton(onClick = { pendingDeleteSale = null }) { Text("না") }
          },
        )
      }
    }
  }
}

@Composable
private fun GlassTopBar(
  shopName: String,
  isOnline: Boolean,
  hasConfiguredDrive: Boolean,
  driveCount: Int,
  syncState: SyncVisualState,
  onEditShop: () -> Unit,
  onOpenDrive: () -> Unit,
  onOpenTheme: () -> Unit,
) {
  val glass = LocalGlassPalette.current
  Box(
    modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 14.dp, vertical = 8.dp)
  ) {
    GlassCard(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(22.dp),
      innerPadding = 11.dp,
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier =
            Modifier.weight(1f)
              .clip(RoundedCornerShape(12.dp))
              .clickable { onEditShop() }
              .padding(end = 6.dp)
              .testTag("top_bar_shop_profile_button"),
        ) {
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = Color.Transparent,
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.35f)),
            modifier = Modifier.size(42.dp),
          ) {
            Box(
              modifier =
                Modifier.background(
                  Brush.linearGradient(listOf(glass.accent, glass.secondaryAccent))
                ),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                Icons.Default.Storefront,
                contentDescription = shopName,
                tint = Color.White,
                modifier = Modifier.size(22.dp),
              )
            }
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = shopName,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = glass.textPrimary,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier =
                  Modifier.size(7.dp)
                    .clip(CircleShape)
                    .background(if (isOnline) ProfitGreen else WarningAmber)
              )
              Spacer(modifier = Modifier.width(5.dp))
              Text(
                text = if (isOnline) "অনলাইন • অফলাইন রেডি" else "অফলাইন মোড (সুরক্ষিত)",
                style = MaterialTheme.typography.labelSmall,
                color = glass.textSecondary,
                maxLines = 1,
              )
            }
          }
        }

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          val driveTint =
            when {
              syncState == SyncVisualState.ERROR -> DangerRose
              hasConfiguredDrive -> ProfitGreen
              else -> glass.textSecondary
            }
          Surface(
            onClick = onOpenDrive,
            shape = RoundedCornerShape(50),
            color = driveTint.copy(alpha = 0.14f),
            border = BorderStroke(1.dp, driveTint.copy(alpha = 0.3f)),
            modifier = Modifier.testTag("open_drive_backup_button"),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector =
                  when {
                    syncState == SyncVisualState.SYNCING -> Icons.Default.CloudSync
                    hasConfiguredDrive -> Icons.Default.Cloud
                    else -> Icons.Default.CloudOff
                  },
                contentDescription = "গুগল ড্রাইভ ব্যাকআপ",
                tint = driveTint,
                modifier = Modifier.size(16.dp),
              )
              Spacer(modifier = Modifier.width(5.dp))
              Text(
                text = if (driveCount > 0) "ড্রাইভ ($driveCount)" else "ড্রাইভ",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = driveTint,
              )
            }
          }

          GlassTintedIconButton(
            icon = Icons.Default.Palette,
            contentDescription = "থিম স্টুডিও",
            tint = glass.accent,
            onClick = onOpenTheme,
            modifier = Modifier.testTag("open_theme_studio_button"),
          )
        }
      }
    }
  }
}
