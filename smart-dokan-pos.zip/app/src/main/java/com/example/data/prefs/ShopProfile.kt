package com.example.data.prefs

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class ShopProfile(
  val shopName: String = "Smart Dokan POS",
  val shopSubtitle: String = "রিটেইল, কসমেটিক্স ও ফার্মেসি ম্যানেজার",
  val phone: String = "",
  val address: String = "",
  val currencySymbol: String = "৳",
  val lowStockThreshold: Int = 5,
)
