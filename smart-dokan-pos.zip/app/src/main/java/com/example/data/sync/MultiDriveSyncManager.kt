package com.example.data.sync

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.example.data.local.PosRepository
import com.example.data.prefs.DriveDataScope
import com.example.data.prefs.DriveLinkStatus
import com.example.data.prefs.PreferencesManager
import com.example.data.prefs.UserDriveLink
import com.example.security.VaultCrypto
import com.squareup.moshi.Moshi
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

data class SyncOutcome(
  val syncedLabels: List<String>,
  val failoverUsed: Boolean,
  val timestamp: Long,
)

data class RestoreOutcome(
  val sourceLabel: String,
  val productCount: Int,
  val saleCount: Int,
)

class MultiDriveSyncManager(
  private val context: Context,
  private val repository: PosRepository,
  private val prefs: PreferencesManager,
) {
  private val moshi = Moshi.Builder().build()
  private val snapshotAdapter = moshi.adapter(BackupSnapshot::class.java)
  private val envelopeAdapter = moshi.adapter(EncryptedVaultEnvelope::class.java)
  private val reqAdapter = moshi.adapter(AppsScriptSyncRequest::class.java)
  private val resAdapter = moshi.adapter(AppsScriptSyncResponse::class.java)

  private val httpClient =
    OkHttpClient.Builder()
      .connectTimeout(25, TimeUnit.SECONDS)
      .readTimeout(40, TimeUnit.SECONDS)
      .writeTimeout(40, TimeUnit.SECONDS)
      .followRedirects(true)
      .build()

  fun isOnline(): Boolean {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
    val net = cm.activeNetwork ?: return false
    val caps = cm.getNetworkCapabilities(net) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
  }

  suspend fun buildEncryptedEnvelopeJson(passphrase: String): Pair<EncryptedVaultEnvelope, String> {
    val (products, sales) = repository.exportSnapshotData()
    val theme = prefs.getThemeConfigOnce()
    val shop = prefs.getShopProfileOnce()
    val snapshot =
      BackupSnapshot(themeConfig = theme, shopProfile = shop, products = products, sales = sales)
    val plainJson = snapshotAdapter.toJson(snapshot)
    val envelope = VaultCrypto.encrypt(plainJson, passphrase)
    return envelope to envelopeAdapter.toJson(envelope)
  }

  suspend fun restoreFromEnvelopeJson(envelopeJson: String, passphrase: String): RestoreOutcome {
    val envelope =
      envelopeAdapter.fromJson(envelopeJson)
        ?: throw IllegalArgumentException("ব্যাকআপ ফাইলের ফরম্যাট সঠিক নয়।")
    return applyEncryptedEnvelope(envelope, passphrase, "ফাইল ব্যাকআপ")
  }

  private suspend fun applyEncryptedEnvelope(
    envelope: EncryptedVaultEnvelope,
    passphrase: String,
    sourceLabel: String,
  ): RestoreOutcome {
    val plainJson = VaultCrypto.decrypt(envelope, passphrase)
    val snapshot =
      snapshotAdapter.fromJson(plainJson)
        ?: throw IllegalArgumentException("ডিক্রিপ্টেড ডাটা পড়া যায়নি।")
    repository.restoreSnapshotData(snapshot.products, snapshot.sales)
    prefs.saveThemeConfig(snapshot.themeConfig)
    prefs.saveShopProfile(snapshot.shopProfile)
    return RestoreOutcome(
      sourceLabel = sourceLabel,
      productCount = snapshot.products.size,
      saleCount = snapshot.sales.size,
    )
  }

  /**
   * Multi-Folder + Multi-Drive Failover Sync:
   * 1. Dedicated category folder links (PRODUCTS_ONLY, SALES_ONLY, SHORTLIST_ONLY)
   *    automatically receive their assigned data in their respective Google Drive folders.
   * 2. Full backup links (ALL_AUTO_SUBFOLDERS / ENCRYPTED_VAULT_ONLY) run in priority order
   *    with automatic quota/error failover (#1 -> #2 -> #3).
   */
  suspend fun syncWithFailover(passphrase: String): SyncOutcome =
    withContext(Dispatchers.IO) {
      if (!isOnline()) {
        throw IllegalStateException("ইন্টারনেট সংযোগ নেই। অনলাইনে এলে স্বয়ংক্রিয়ভাবে সিঙ্ক হবে।")
      }
      val allLinks = prefs.getDriveLinksOnce()
      val enabledLinks = allLinks.filter { it.enabled }
      if (enabledLinks.isEmpty()) {
        throw IllegalStateException("প্রথমে আপনার অন্তত একটি গুগল ড্রাইভ লিংক যোগ ও সক্রিয় করুন।")
      }

      val (products, sales) = repository.exportSnapshotData()
      val theme = prefs.getThemeConfigOnce()
      val shop = prefs.getShopProfileOnce()
      val snapshot =
        BackupSnapshot(themeConfig = theme, shopProfile = shop, products = products, sales = sales)
      val envelope = VaultCrypto.encrypt(snapshotAdapter.toJson(snapshot), passphrase)
      val todayKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
      val shortList = products.filter { it.stock <= shop.lowStockThreshold }

      var updatedLinks = allLinks.toMutableList()
      val syncedLabels = mutableListOf<String>()
      var failoverTriggered = false
      var lastError = "অজানা ত্রুটি"

      // 1. Specialized folder-routed links (Products, Sales, ShortList) all sync to their target folders
      val specializedLinks =
        enabledLinks.filter {
          it.dataScope == DriveDataScope.PRODUCTS_ONLY ||
            it.dataScope == DriveDataScope.SALES_ONLY ||
            it.dataScope == DriveDataScope.SHORTLIST_ONLY
        }
      for (node in specializedLinks) {
        val scopedData =
          when (node.dataScope) {
            DriveDataScope.PRODUCTS_ONLY ->
              StructuredFolderPayload(dateKey = todayKey, products = products)
            DriveDataScope.SALES_ONLY ->
              StructuredFolderPayload(dateKey = todayKey, sales = sales)
            DriveDataScope.SHORTLIST_ONLY ->
              StructuredFolderPayload(dateKey = todayKey, shortList = shortList)
            else -> null
          }
        try {
          val req =
            AppsScriptSyncRequest(
              mode = "sync",
              folderId = node.folderId,
              dataScope = node.dataScope.name,
              autoSubfolders = node.autoSubfolders,
              dateKey = todayKey,
              payload = envelope,
              structuredData = scopedData,
            )
          val res = postToAppsScript(node.scriptEndpointUrl, req)
          if (res.success) {
            val now = System.currentTimeMillis()
            val updated =
              node.copy(status = DriveLinkStatus.SYNCED, lastSyncedAt = now, lastError = "")
            updatedLinks = updatedLinks.map { if (it.id == node.id) updated else it }.toMutableList()
            syncedLabels += node.label
          } else {
            val st = if (res.quotaFull) DriveLinkStatus.QUOTA_FULL else DriveLinkStatus.ERROR
            val err = res.error ?: "ফোল্ডার সিঙ্ক ব্যর্থ"
            updatedLinks =
              updatedLinks
                .map { if (it.id == node.id) it.copy(status = st, lastError = err) else it }
                .toMutableList()
            lastError = err
          }
        } catch (e: Exception) {
          val err = e.message ?: "নেটওয়ার্ক ত্রুটি"
          updatedLinks =
            updatedLinks
              .map {
                if (it.id == node.id) it.copy(status = DriveLinkStatus.ERROR, lastError = err)
                else it
              }
              .toMutableList()
          lastError = err
        }
      }

      // 2. Full backup links (ALL_AUTO_SUBFOLDERS / ENCRYPTED_VAULT_ONLY) with automatic failover
      val fullLinks =
        enabledLinks.filter {
          it.dataScope == DriveDataScope.ALL_AUTO_SUBFOLDERS ||
            it.dataScope == DriveDataScope.ENCRYPTED_VAULT_ONLY
        }
      val fullPayloadData =
        StructuredFolderPayload(
          dateKey = todayKey,
          products = products,
          sales = sales,
          shortList = shortList,
        )

      for (candidate in fullLinks) {
        try {
          val req =
            AppsScriptSyncRequest(
              mode = "sync",
              folderId = candidate.folderId,
              dataScope = candidate.dataScope.name,
              autoSubfolders = candidate.autoSubfolders,
              dateKey = todayKey,
              payload = envelope,
              structuredData =
                if (candidate.dataScope == DriveDataScope.ALL_AUTO_SUBFOLDERS) fullPayloadData
                else null,
            )
          val res = postToAppsScript(candidate.scriptEndpointUrl, req)
          if (!res.success) {
            val st = if (res.quotaFull) DriveLinkStatus.QUOTA_FULL else DriveLinkStatus.ERROR
            val err = res.error ?: "ড্রাইভ সিঙ্ক ব্যর্থ হয়েছে।"
            updatedLinks =
              updatedLinks
                .map { if (it.id == candidate.id) it.copy(status = st, lastError = err) else it }
                .toMutableList()
            lastError = err
            failoverTriggered = true
            continue
          }

          val now = System.currentTimeMillis()
          val syncedNode =
            candidate.copy(status = DriveLinkStatus.SYNCED, lastSyncedAt = now, lastError = "")
          updatedLinks =
            updatedLinks.map { if (it.id == candidate.id) syncedNode else it }.toMutableList()
          syncedLabels += syncedNode.label
          break
        } catch (e: Exception) {
          val err = e.message ?: "নেটওয়ার্ক ত্রুটি"
          updatedLinks =
            updatedLinks
              .map {
                if (it.id == candidate.id) {
                  it.copy(status = DriveLinkStatus.ERROR, lastError = err)
                } else {
                  it
                }
              }
              .toMutableList()
          lastError = err
          failoverTriggered = true
        }
      }

      prefs.saveDriveLinks(updatedLinks)
      if (syncedLabels.isEmpty()) {
        throw IllegalStateException("সবগুলো ড্রাইভ লিংকে ব্যাকআপ ব্যর্থ হয়েছে: $lastError")
      }

      val now = System.currentTimeMillis()
      val labelSummary = syncedLabels.joinToString(" + ")
      prefs.recordLastSync(now, labelSummary)
      SyncOutcome(syncedLabels = syncedLabels, failoverUsed = failoverTriggered, timestamp = now)
    }

  suspend fun restoreFromDriveLink(link: UserDriveLink, passphrase: String): RestoreOutcome =
    withContext(Dispatchers.IO) {
      if (!isOnline()) throw IllegalStateException("রিস্টোর করতে ইন্টারনেট সংযোগ প্রয়োজন।")
      val req =
        AppsScriptSyncRequest(
          mode = "restore",
          folderId = link.folderId,
          dataScope = link.dataScope.name,
          autoSubfolders = link.autoSubfolders,
        )
      val res = postToAppsScript(link.scriptEndpointUrl, req)
      if (!res.success || res.encryptedPayload == null) {
        throw IllegalStateException(res.error ?: "এই ড্রাইভ ফোল্ডারে কোনো ব্যাকআপ ফাইল পাওয়া যায়নি।")
      }
      applyEncryptedEnvelope(res.encryptedPayload, passphrase, link.label)
    }

  suspend fun testDriveLink(link: UserDriveLink): String =
    withContext(Dispatchers.IO) {
      if (!isOnline()) throw IllegalStateException("ইন্টারনেট সংযোগ নেই।")
      val req =
        AppsScriptSyncRequest(
          mode = "ping",
          folderId = link.folderId,
          dataScope = link.dataScope.name,
          autoSubfolders = link.autoSubfolders,
        )
      val res = postToAppsScript(link.scriptEndpointUrl, req)
      if (!res.success) {
        throw IllegalStateException(res.error ?: "ড্রাইভ লিংকটি কাজ করছে না।")
      }
      "ড্রাইভ লিংক ও ফোল্ডার সঠিকভাবে সংযুক্ত আছে!"
    }

  private fun postToAppsScript(url: String, bodyObj: AppsScriptSyncRequest): AppsScriptSyncResponse {
    if (!url.startsWith("https://script.google.com/macros/")) {
      throw IllegalArgumentException("অবৈধ লিংক! শুধুমাত্র https://script.google.com/macros/... লিংক দিন।")
    }
    val json = reqAdapter.toJson(bodyObj)
    val body = json.toRequestBody("text/plain; charset=utf-8".toMediaType())
    val request = Request.Builder().url(url).post(body).build()

    httpClient.newCall(request).execute().use { resp ->
      val raw = resp.body?.string() ?: throw IllegalStateException("সার্ভার থেকে খালি উত্তর এসেছে।")
      return runCatching { resAdapter.fromJson(raw) }.getOrNull()
        ?: throw IllegalStateException(
          "সঠিক উত্তর পাওয়া যায়নি। Apps Script Deploy-এ Access = Anyone দেওয়া আছে কিনা দেখুন।"
        )
    }
  }
}
