package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [ProductEntity::class, SaleEntity::class], version = 2, exportSchema = false)
abstract class PosDatabase : RoomDatabase() {
  abstract fun posDao(): PosDao

  companion object {
    @Volatile private var INSTANCE: PosDatabase? = null

    private val MIGRATION_1_2 =
      object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
          db.execSQL("ALTER TABLE products ADD COLUMN imagePath TEXT NOT NULL DEFAULT ''")
        }
      }

    fun getInstance(context: Context): PosDatabase {
      return INSTANCE
        ?: synchronized(this) {
          INSTANCE
            ?: Room.databaseBuilder(
                context.applicationContext,
                PosDatabase::class.java,
                "smart_dokan_pos.db",
              )
              .addMigrations(MIGRATION_1_2)
              .build()
              .also { INSTANCE = it }
        }
    }
  }
}
