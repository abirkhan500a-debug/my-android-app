package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
@Entity(tableName = "products")
data class ProductEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val name: String,
  val buyingPrice: Double,
  val sellingPrice: Double,
  val stock: Int,
  val boxLocation: String = "",
  val brandName: String = "",
  val genericName: String = "",
  val expiryDateIso: String = "",
  val notes: String = "",
  val imagePath: String = "",
  val createdAt: Long = System.currentTimeMillis(),
  val updatedAt: Long = System.currentTimeMillis(),
) {
  val unitProfit: Double
    get() = sellingPrice - buyingPrice

  val marginPercent: Double
    get() = if (sellingPrice > 0.0) ((unitProfit / sellingPrice) * 100.0) else 0.0
}
