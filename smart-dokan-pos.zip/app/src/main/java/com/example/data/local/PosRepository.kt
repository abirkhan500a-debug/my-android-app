package com.example.data.local

import kotlinx.coroutines.flow.Flow

class PosRepository(private val dao: PosDao) {
  val products: Flow<List<ProductEntity>> = dao.getAllProducts()
  val sales: Flow<List<SaleEntity>> = dao.getAllSales()

  suspend fun saveProduct(product: ProductEntity): Long {
    val now = System.currentTimeMillis()
    val normalized =
      product.copy(
        name = product.name.trim(),
        boxLocation = product.boxLocation.trim(),
        brandName = product.brandName.trim(),
        genericName = product.genericName.trim(),
        notes = product.notes.trim(),
        imagePath = product.imagePath.trim(),
        stock = product.stock.coerceAtLeast(0),
        updatedAt = now,
        createdAt = if (product.id == 0L) now else product.createdAt,
      )
    return dao.upsertProduct(normalized)
  }

  suspend fun deleteProduct(id: Long) = dao.deleteProductById(id)

  suspend fun restockProduct(product: ProductEntity, addedQty: Int = 10) {
    dao.upsertProduct(
      product.copy(
        stock = (product.stock + addedQty).coerceAtLeast(0),
        updatedAt = System.currentTimeMillis(),
      )
    )
  }

  suspend fun recordSale(productId: Long, quantity: Int): SaleEntity {
    return dao.recordSaleAtomically(productId, quantity)
  }

  suspend fun updateSale(
    saleId: Long,
    newQty: Int,
    newBuyingPrice: Double,
    newSellingPrice: Double,
    newDateKey: String,
  ): SaleEntity {
    return dao.updateSaleAtomically(saleId, newQty, newBuyingPrice, newSellingPrice, newDateKey)
  }

  suspend fun deleteSaleAndRestoreStock(saleId: Long): SaleEntity {
    return dao.deleteSaleAndRestoreStock(saleId)
  }

  suspend fun exportSnapshotData(): Pair<List<ProductEntity>, List<SaleEntity>> {
    return dao.getAllProductsOnce() to dao.getAllSalesOnce()
  }

  suspend fun restoreSnapshotData(products: List<ProductEntity>, sales: List<SaleEntity>) {
    dao.replaceAllFromBackup(products, sales)
  }
}
