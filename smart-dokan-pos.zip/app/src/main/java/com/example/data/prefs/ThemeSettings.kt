package com.example.data.prefs

import com.squareup.moshi.JsonClass

enum class ThemePreset(
  val id: String,
  val labelBn: String,
  val isDark: Boolean,
  val accentHex: Long,
  val secondaryAccentHex: Long,
  val bgStartHex: Long,
  val bgMidHex: Long,
  val bgEndHex: Long,
) {
  EMERALD_MINT(
    id = "emerald_mint",
    labelBn = "এম্যারেল্ড মিন্ট (ডিফল্ট)",
    isDark = false,
    accentHex = 0xFF059669,
    secondaryAccentHex = 0xFF0D9488,
    bgStartHex = 0xFFD1FAE5,
    bgMidHex = 0xFFECFDF5,
    bgEndHex = 0xFFCCFBF1,
  ),
  ROYAL_OCEAN(
    id = "royal_ocean",
    labelBn = "রয়্যাল ওশান ব্লু",
    isDark = false,
    accentHex = 0xFF2563EB,
    secondaryAccentHex = 0xFF0284C7,
    bgStartHex = 0xFFDBEAFE,
    bgMidHex = 0xFFEFF6FF,
    bgEndHex = 0xFFE0F2FE,
  ),
  SUNSET_AMBER(
    id = "sunset_amber",
    labelBn = "সানসেট অ্যাম্বার",
    isDark = false,
    accentHex = 0xFFD97706,
    secondaryAccentHex = 0xFFEA580C,
    bgStartHex = 0xFFFEF3C7,
    bgMidHex = 0xFFFFFBEB,
    bgEndHex = 0xFFFFEDD5,
  ),
  MIDNIGHT_DARK(
    id = "midnight_dark",
    labelBn = "মিডনাইট ডার্ক গ্লাস",
    isDark = true,
    accentHex = 0xFF10B981,
    secondaryAccentHex = 0xFF38BDF8,
    bgStartHex = 0xFF020617,
    bgMidHex = 0xFF0F172A,
    bgEndHex = 0xFF064E3B,
  ),
  ROSE_QUARTZ(
    id = "rose_quartz",
    labelBn = "রোজ কোয়ার্টজ",
    isDark = false,
    accentHex = 0xFFE11D48,
    secondaryAccentHex = 0xFFDB2777,
    bgStartHex = 0xFFFFE4E6,
    bgMidHex = 0xFFFFF1F2,
    bgEndHex = 0xFFFCE7F3,
  ),
  MINIMALIST_LIGHT(
    id = "minimalist_light",
    labelBn = "ক্লিন মিনিমালিস্ট লাইট",
    isDark = false,
    accentHex = 0xFF18181B,
    secondaryAccentHex = 0xFF52525B,
    bgStartHex = 0xFFF4F4F5,
    bgMidHex = 0xFFFFFFFF,
    bgEndHex = 0xFFE4E4E7,
  );

  companion object {
    fun fromId(id: String?): ThemePreset = entries.firstOrNull { it.id == id } ?: EMERALD_MINT
  }
}

enum class MeshStyle(val labelBn: String) {
  AURORA("অরোরা মেশ"),
  DIAGONAL("ডায়াগোনাল ফ্লো"),
  RADIAL("রেডিয়াল গ্লো"),
}

enum class BlurIntensity(val labelBn: String, val cardAlphaLight: Float, val cardAlphaDark: Float) {
  LOW("হালকা (Low)", 0.84f, 0.72f),
  MEDIUM("মাঝারি (Medium)", 0.72f, 0.58f),
  HIGH("ঘন (High)", 0.58f, 0.44f),
}

@JsonClass(generateAdapter = true)
data class ThemeConfig(
  val presetId: String = ThemePreset.EMERALD_MINT.id,
  val customAccentHex: Long = ThemePreset.EMERALD_MINT.accentHex,
  val customBgStartHex: Long = ThemePreset.EMERALD_MINT.bgStartHex,
  val customBgEndHex: Long = ThemePreset.EMERALD_MINT.bgEndHex,
  val meshStyle: MeshStyle = MeshStyle.AURORA,
  val blurIntensity: BlurIntensity = BlurIntensity.MEDIUM,
) {
  val preset: ThemePreset
    get() = ThemePreset.fromId(presetId)
}
