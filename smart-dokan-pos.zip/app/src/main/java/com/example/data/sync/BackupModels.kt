package com.example.data.sync

import com.example.data.local.ProductEntity
import com.example.data.local.SaleEntity
import com.example.data.prefs.ShopProfile
import com.example.data.prefs.ThemeConfig
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class BackupSnapshot(
  val app: String = "Smart Dokan POS",
  val schemaVersion: Int = 2,
  val exportedAt: Long = System.currentTimeMillis(),
  val themeConfig: ThemeConfig,
  val shopProfile: ShopProfile = ShopProfile(),
  val products: List<ProductEntity>,
  val sales: List<SaleEntity>,
)

@JsonClass(generateAdapter = true)
data class EncryptedVaultEnvelope(
  val v: Int = 1,
  val alg: String = "AES-256-GCM",
  val salt: String,
  val iv: String,
  val ciphertext: String,
  val createdAt: Long,
)

@JsonClass(generateAdapter = true)
data class StructuredFolderPayload(
  val dateKey: String,
  val products: List<ProductEntity>? = null,
  val sales: List<SaleEntity>? = null,
  val shortList: List<ProductEntity>? = null,
)

@JsonClass(generateAdapter = true)
data class AppsScriptSyncRequest(
  val mode: String, // "sync" | "restore" | "ping"
  val filename: String = "smart-dokan-pos-vault.enc.json",
  val folderId: String = "",
  val dataScope: String = "ALL_AUTO_SUBFOLDERS",
  val autoSubfolders: Boolean = true,
  val dateKey: String = "",
  val payload: EncryptedVaultEnvelope? = null,
  val structuredData: StructuredFolderPayload? = null,
)

@JsonClass(generateAdapter = true)
data class AppsScriptSyncResponse(
  val success: Boolean = false,
  val error: String? = null,
  val quotaFull: Boolean = false,
  val syncedAt: String? = null,
  val foldersUsed: List<String>? = null,
  val encryptedPayload: EncryptedVaultEnvelope? = null,
)
