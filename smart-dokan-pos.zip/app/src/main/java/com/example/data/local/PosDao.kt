package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.flow.Flow

@Dao
interface PosDao {
  @Query("SELECT * FROM products ORDER BY updatedAt DESC")
  fun getAllProducts(): Flow<List<ProductEntity>>

  @Query("SELECT * FROM products ORDER BY updatedAt DESC")
  suspend fun getAllProductsOnce(): List<ProductEntity>

  @Query("SELECT * FROM sales ORDER BY timestamp DESC")
  fun getAllSales(): Flow<List<SaleEntity>>

  @Query("SELECT * FROM sales ORDER BY timestamp DESC")
  suspend fun getAllSalesOnce(): List<SaleEntity>

  @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
  suspend fun getProductById(id: Long): ProductEntity?

  @Query("SELECT * FROM sales WHERE id = :id LIMIT 1")
  suspend fun getSaleById(id: Long): SaleEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertProduct(product: ProductEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertProducts(products: List<ProductEntity>)

  @Query("DELETE FROM products WHERE id = :id")
  suspend fun deleteProductById(id: Long)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSale(sale: SaleEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSales(sales: List<SaleEntity>)

  @Query("DELETE FROM sales WHERE id = :id")
  suspend fun deleteSaleById(id: Long)

  @Query("DELETE FROM products")
  suspend fun clearProducts()

  @Query("DELETE FROM sales")
  suspend fun clearSales()

  @Transaction
  suspend fun recordSaleAtomically(productId: Long, quantity: Int): SaleEntity {
    val qty = quantity.coerceAtLeast(1)
    val product = getProductById(productId) ?: throw IllegalStateException("পণ্যটি খুঁজে পাওয়া যায়নি।")
    if (product.stock < qty) {
      throw IllegalStateException("পর্যাপ্ত স্টক নেই! বর্তমান স্টক: ${product.stock}")
    }
    val now = System.currentTimeMillis()
    val updatedProduct = product.copy(stock = product.stock - qty, updatedAt = now)
    upsertProduct(updatedProduct)

    val revenue = product.sellingPrice * qty
    val cost = product.buyingPrice * qty
    val profit = revenue - cost
    val dateKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(now))

    val sale =
      SaleEntity(
        productId = product.id,
        productName = product.name,
        genericName = product.genericName,
        boxLocation = product.boxLocation,
        quantity = qty,
        buyingPriceAtSale = product.buyingPrice,
        sellingPriceAtSale = product.sellingPrice,
        totalRevenue = revenue,
        totalCost = cost,
        netProfit = profit,
        dateKey = dateKey,
        timestamp = now,
      )
    val insertedId = insertSale(sale)
    return sale.copy(id = insertedId)
  }

  /**
   * Atomically updates an existing sale record and reconciles product stock delta.
   */
  @Transaction
  suspend fun updateSaleAtomically(
    saleId: Long,
    newQty: Int,
    newBuyingPrice: Double,
    newSellingPrice: Double,
    newDateKey: String,
  ): SaleEntity {
    val qty = newQty.coerceAtLeast(1)
    val existingSale = getSaleById(saleId) ?: throw IllegalStateException("বিক্রয় রেকর্ডটি পাওয়া যায়নি।")
    val qtyDelta = qty - existingSale.quantity
    val product = getProductById(existingSale.productId)
    if (product != null && qtyDelta > 0 && product.stock < qtyDelta) {
      throw IllegalStateException("স্টক পর্যাপ্ত নয়! অতিরিক্ত ${qtyDelta} পিস নেই।")
    }
    if (product != null && qtyDelta != 0) {
      upsertProduct(
        product.copy(
          stock = (product.stock - qtyDelta).coerceAtLeast(0),
          updatedAt = System.currentTimeMillis(),
        )
      )
    }

    val revenue = newSellingPrice * qty
    val cost = newBuyingPrice * qty
    val updated =
      existingSale.copy(
        quantity = qty,
        buyingPriceAtSale = newBuyingPrice,
        sellingPriceAtSale = newSellingPrice,
        totalRevenue = revenue,
        totalCost = cost,
        netProfit = revenue - cost,
        dateKey = newDateKey.ifBlank { existingSale.dateKey },
      )
    insertSale(updated)
    return updated
  }

  /**
   * Atomically deletes/reverses a sale and restores sold quantity back to product stock.
   */
  @Transaction
  suspend fun deleteSaleAndRestoreStock(saleId: Long): SaleEntity {
    val existingSale = getSaleById(saleId) ?: throw IllegalStateException("বিক্রয় রেকর্ডটি পাওয়া যায়নি।")
    val product = getProductById(existingSale.productId)
    if (product != null) {
      upsertProduct(
        product.copy(
          stock = product.stock + existingSale.quantity,
          updatedAt = System.currentTimeMillis(),
        )
      )
    }
    deleteSaleById(saleId)
    return existingSale
  }

  @Transaction
  suspend fun replaceAllFromBackup(products: List<ProductEntity>, sales: List<SaleEntity>) {
    clearProducts()
    clearSales()
    insertProducts(products)
    insertSales(sales)
  }
}
