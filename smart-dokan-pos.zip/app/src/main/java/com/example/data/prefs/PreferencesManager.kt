package com.example.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "smart_dokan_prefs")

class PreferencesManager(private val context: Context) {
  private val moshi = Moshi.Builder().build()
  private val themeAdapter = moshi.adapter(ThemeConfig::class.java)
  private val shopProfileAdapter = moshi.adapter(ShopProfile::class.java)
  private val driveListType = Types.newParameterizedType(List::class.java, UserDriveLink::class.java)
  private val driveListAdapter = moshi.adapter<List<UserDriveLink>>(driveListType)

  private object Keys {
    val THEME_JSON = stringPreferencesKey("theme_config_json")
    val SHOP_PROFILE_JSON = stringPreferencesKey("shop_profile_json")
    val DRIVE_LINKS_JSON = stringPreferencesKey("user_drive_links_json")
    val DEFAULT_BRIDGE_URL = stringPreferencesKey("default_apps_script_bridge_url")
    val AUTO_SYNC = booleanPreferencesKey("auto_sync_enabled")
    val LAST_SYNCED_AT = longPreferencesKey("last_synced_at")
    val ACTIVE_DRIVE_LABEL = stringPreferencesKey("active_drive_label")
  }

  val themeConfig: Flow<ThemeConfig> =
    context.dataStore.data.map { prefs ->
      prefs[Keys.THEME_JSON]?.let { json ->
        runCatching { themeAdapter.fromJson(json) }.getOrNull()
      } ?: ThemeConfig()
    }

  val shopProfile: Flow<ShopProfile> =
    context.dataStore.data.map { prefs ->
      prefs[Keys.SHOP_PROFILE_JSON]?.let { json ->
        runCatching { shopProfileAdapter.fromJson(json) }.getOrNull()
      } ?: ShopProfile()
    }

  val driveLinks: Flow<List<UserDriveLink>> =
    context.dataStore.data.map { prefs ->
      prefs[Keys.DRIVE_LINKS_JSON]?.let { json ->
        runCatching { driveListAdapter.fromJson(json) }.getOrNull()
      } ?: emptyList()
    }

  val defaultBridgeUrl: Flow<String> =
    context.dataStore.data.map { prefs -> prefs[Keys.DEFAULT_BRIDGE_URL] ?: "" }

  val autoSyncEnabled: Flow<Boolean> =
    context.dataStore.data.map { prefs -> prefs[Keys.AUTO_SYNC] ?: true }

  val lastSyncedAt: Flow<Long?> =
    context.dataStore.data.map { prefs -> prefs[Keys.LAST_SYNCED_AT] }

  val activeDriveLabel: Flow<String?> =
    context.dataStore.data.map { prefs -> prefs[Keys.ACTIVE_DRIVE_LABEL] }

  suspend fun saveThemeConfig(config: ThemeConfig) {
    context.dataStore.edit { prefs -> prefs[Keys.THEME_JSON] = themeAdapter.toJson(config) }
  }

  suspend fun getThemeConfigOnce(): ThemeConfig = themeConfig.first()

  suspend fun saveShopProfile(profile: ShopProfile) {
    context.dataStore.edit { prefs ->
      prefs[Keys.SHOP_PROFILE_JSON] = shopProfileAdapter.toJson(profile)
    }
  }

  suspend fun getShopProfileOnce(): ShopProfile = shopProfile.first()

  suspend fun saveDriveLinks(links: List<UserDriveLink>) {
    context.dataStore.edit { prefs -> prefs[Keys.DRIVE_LINKS_JSON] = driveListAdapter.toJson(links) }
  }

  suspend fun saveDefaultBridgeUrl(url: String) {
    context.dataStore.edit { prefs -> prefs[Keys.DEFAULT_BRIDGE_URL] = url.trim() }
  }

  suspend fun getDriveLinksOnce(): List<UserDriveLink> = driveLinks.first()

  suspend fun setAutoSync(enabled: Boolean) {
    context.dataStore.edit { prefs -> prefs[Keys.AUTO_SYNC] = enabled }
  }

  suspend fun recordLastSync(timestamp: Long, driveLabel: String) {
    context.dataStore.edit { prefs ->
      prefs[Keys.LAST_SYNCED_AT] = timestamp
      prefs[Keys.ACTIVE_DRIVE_LABEL] = driveLabel
    }
  }
}
