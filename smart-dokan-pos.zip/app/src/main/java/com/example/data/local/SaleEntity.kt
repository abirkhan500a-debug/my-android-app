package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
@Entity(tableName = "sales")
data class SaleEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val productId: Long,
  val productName: String,
  val genericName: String = "",
  val boxLocation: String = "",
  val quantity: Int,
  val buyingPriceAtSale: Double,
  val sellingPriceAtSale: Double,
  val totalRevenue: Double,
  val totalCost: Double,
  val netProfit: Double,
  val dateKey: String,
  val timestamp: Long = System.currentTimeMillis(),
)
