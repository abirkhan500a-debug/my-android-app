package com.example.data.prefs

import com.squareup.moshi.JsonClass

enum class DriveLinkStatus(val labelBn: String) {
  READY("প্রস্তুত"),
  SYNCED("সিঙ্ক সম্পন্ন"),
  QUOTA_FULL("স্টোরেজ পূর্ণ"),
  ERROR("ত্রুটি"),
}

enum class DriveDataScope(val labelBn: String, val shortLabelBn: String) {
  ALL_AUTO_SUBFOLDERS("সকল ডাটা (অটো আলাদা ফোল্ডার)", "সব ডাটা • অটো ফোল্ডার"),
  PRODUCTS_ONLY("শুধু পণ্যের তালিকা (Products)", "শুধু পণ্য"),
  SALES_ONLY("শুধু বিক্রি ও লাভ (Sales & Profit)", "শুধু বিক্রি ও লাভ"),
  SHORTLIST_ONLY("শুধু শর্ট লিস্ট (Low Stock)", "শুধু শর্ট লিস্ট"),
  ENCRYPTED_VAULT_ONLY("শুধু এনক্রিপ্টেড ভল্ট (Restore)", "শুধু ভল্ট"),
}

@JsonClass(generateAdapter = true)
data class UserDriveLink(
  val id: String,
  val label: String,
  val scriptEndpointUrl: String,
  val driveFolderUrl: String = "",
  val folderId: String = "",
  val dataScope: DriveDataScope = DriveDataScope.ALL_AUTO_SUBFOLDERS,
  val autoSubfolders: Boolean = true,
  val enabled: Boolean = true,
  val status: DriveLinkStatus = DriveLinkStatus.READY,
  val lastSyncedAt: Long? = null,
  val lastError: String = "",
)

object DriveLinkParser {
  private val FOLDER_REGEX = Regex("""/folders/([a-zA-Z0-9_-]+)""")
  private val RAW_ID_REGEX = Regex("""^[a-zA-Z0-9_-]{25,}$""")

  fun extractFolderId(input: String): String {
    val trimmed = input.trim()
    if (trimmed.isEmpty()) return ""
    FOLDER_REGEX.find(trimmed)?.groupValues?.getOrNull(1)?.let { return it }
    if (RAW_ID_REGEX.matches(trimmed)) return trimmed
    return ""
  }

  fun isValidAppsScriptEndpoint(url: String): Boolean {
    val trimmed = url.trim()
    return trimmed.startsWith("https://script.google.com/macros/")
  }

  fun isValidDriveFolderInput(input: String): Boolean {
    val trimmed = input.trim()
    if (trimmed.isEmpty()) return true // Optional
    return extractFolderId(trimmed).isNotEmpty()
  }
}
