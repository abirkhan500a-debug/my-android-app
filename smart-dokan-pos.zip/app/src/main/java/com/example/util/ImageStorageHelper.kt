package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Copies and scales photos picked via the zero-permission Android Photo Picker
 * into app-private internal storage so product photos persist permanently offline.
 */
object ImageStorageHelper {
  private const val DIR_NAME = "product_images"
  private const val MAX_DIMENSION_PX = 640

  suspend fun savePickedImage(context: Context, sourceUri: Uri): String =
    withContext(Dispatchers.IO) {
      val dir = File(context.filesDir, DIR_NAME).apply { if (!exists()) mkdirs() }
      val targetFile = File(dir, "prod_${System.currentTimeMillis()}.jpg")

      val rawBitmap =
        context.contentResolver.openInputStream(sourceUri)?.use { input ->
          BitmapFactory.decodeStream(input)
        } ?: throw IllegalStateException("ছবিটি পড়া যায়নি। অন্য ছবি নির্বাচন করুন।")

      val scaled = scaleDownIfNeeded(rawBitmap, MAX_DIMENSION_PX)
      FileOutputStream(targetFile).use { out ->
        scaled.compress(Bitmap.CompressFormat.JPEG, 82, out)
      }
      if (scaled !== rawBitmap) scaled.recycle()
      rawBitmap.recycle()

      targetFile.absolutePath
    }

  fun deleteImageFile(path: String) {
    if (path.isBlank()) return
    runCatching {
      val file = File(path)
      if (file.exists() && file.absolutePath.contains(DIR_NAME)) {
        file.delete()
      }
    }
  }

  private fun scaleDownIfNeeded(bitmap: Bitmap, maxDim: Int): Bitmap {
    val w = bitmap.width
    val h = bitmap.height
    if (w <= maxDim && h <= maxDim) return bitmap
    val ratio = maxDim.toFloat() / maxOf(w, h).toFloat()
    val targetW = (w * ratio).toInt().coerceAtLeast(1)
    val targetH = (h * ratio).toInt().coerceAtLeast(1)
    return Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
  }
}
